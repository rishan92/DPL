import nanogpt_bench

benchmark = nanogpt_bench.Benchmark(
    task="shakespeare",
    mode="live",
    search_space_id=1,
)
# Use benchmark object to sample a random configuration.
# config = benchmark.sample_config()
# Alternatively, define configuration as a dictionary.
config = {
    "lr_max": 0.0001,
    "lr_min_percent": 0.1,
    "n_embd": 4,
    "warmup_percent": 0.1,
    "n_layer": 4,
    "n_head": 4,
    "vocab_size": 50304,
    "block_size": 512,
}


results = benchmark(
    config,
    epochs=3,
    global_seed=333,
)

print(f"Sampled configuration: {config}\n" f"Results: {results}")
