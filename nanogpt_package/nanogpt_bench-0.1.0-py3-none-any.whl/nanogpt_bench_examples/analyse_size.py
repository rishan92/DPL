import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

import nanogpt_bench
from nanogpt_bench.lib.core.search_space import get_config_grid

WORKER_DIR = Path(__file__).parent


def run(config_id=None, save_dir=None, worker_dir=None, mode="live"):
    benchmark = nanogpt_bench.Benchmark(
        task="shakespeare_char",
        mode=mode,
        save_dir=save_dir,
        download=False if mode == "table" else True,
    )

    sizes = {}
    flops = {}
    runtimes = {}

    for n_embd in [4, 8, 16, 32, 64, 128]:

        sizes[n_embd] = []
        flops[n_embd] = []
        runtimes[n_embd] = []

        for config in get_config_grid(search_space_id=0):

            _config = config.get_dictionary()
            _config["vocab_size"] = 65

            if _config["n_embd"] != n_embd:
                continue

            results = benchmark(
                _config,
                config_id=config_id,
                worker_dir=worker_dir,
                global_seed=333,
                full_trajectory=True,
                debug=False,
            )

            sizes[n_embd].append(results[-1]["size_bytes"])
            flops[n_embd].append(results[-1]["FLOPS"])
            runtimes[n_embd].append(results[-1]["runtime"])

    _, ax = plt.subplots(1, 3, figsize=(10, 5))

    for i, (metric, metric_name) in enumerate(
        zip([sizes, flops, runtimes], ["size_bytes", "FLOPS", "runtime"])
    ):
        # get the mean and std of the metric
        means = [sum(metric[n_embd]) / len(metric[n_embd]) for n_embd in metric.keys()]
        stds = [np.std(metric[n_embd]) for n_embd in metric.keys()]

        if metric_name == "runtime":
            means = [m / 3600 for m in means]
            stds = [s / 3600 for s in stds]

        # plot the mean and std
        ax[i].plot(metric.keys(), means)
        ax[i].fill_between(
            metric.keys(),
            np.array(means) - np.array(stds),
            np.array(means) + np.array(stds),
            alpha=0.2,
        )

        # set the title and labels
        # ax[i].set_title(f"{metric_name}")
        ax[i].set_xlabel("n_embd")
        ax[i].set_ylabel(f"{metric_name}")
        ax[i].set_xticks(list(metric.keys()))

    plt.tight_layout()
    plt.savefig("analysis/statistics.png")

    _, ax = plt.subplots(2, 3, figsize=(10, 5))

    for i, (key, val) in enumerate(runtimes.items()):

        val = [v / 3600 for v in val]

        ax[i // 3, i % 3].hist(val, bins=10)
        ax[i // 3, i % 3].set_title(f"n_embd = {key}")
        ax[i // 3, i % 3].set_xlabel("runtime")
        ax[i // 3, i % 3].set_ylabel("count")

        # set boundaries for the x-axis
        ax[i // 3, i % 3].set_xlim([12.5, 28.5])

    plt.tight_layout()
    plt.savefig("analysis/runtime_histograms.png")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_id", type=int, default=None)
    parser.add_argument("--save_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--worker_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--mode", type=str, default="table")
    args = parser.parse_args()
    run(
        config_id=args.config_id,
        save_dir=args.save_dir,
        worker_dir=args.worker_dir,
        mode=args.mode,
    )
