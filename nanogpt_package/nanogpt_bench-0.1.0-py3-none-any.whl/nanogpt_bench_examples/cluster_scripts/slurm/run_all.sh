#!/bin/bash

basedir=/home/janowski/PhD/nanoGPT-Bench/nanogpt_bench_examples/
workdir=/work/dlclarge1/janowski-nanogpt_bench/

python "$basedir"/cluster_scripts/slurm/generate_cmds.py

python "$basedir"cluster_scripts/slurm/slurm_helper.py \
    -q relea_gpu-rtx2080 \
    --timelimit 86400 \
    --startup "$basedir"cluster_scripts/slurm/startup.sh \
    --array_min 1 \
    --array_max 300 \
    --memory_per_job 100000 \
    -o "$workdir"LOGS/ \
    -l "$workdir"LOGS/ \
    "$basedir"cluster_scripts/slurm/all_experiments.txt
