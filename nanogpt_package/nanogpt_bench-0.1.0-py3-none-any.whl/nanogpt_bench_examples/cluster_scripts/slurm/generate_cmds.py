import os
from pathlib import Path

ARGS_PATH = Path(__file__).parent
EXP_PATH = ARGS_PATH.parent.parent
OUTPUT_DIR = "/work/dlclarge1/janowski-nanogpt_bench/nanogpt_bench_owt_1/"

CONFIG_IDS = [1]
# CONFIG_IDS = list(range(2, 100))
# CONFIG_IDS = [30, 28, 26, 24, 22, 20, 18, 16]
# CONFIG_IDS = [14, 12, 10, 8, 6, 4]

with open(os.path.join(ARGS_PATH, "all_experiments.txt"), "w+", encoding="UTF-8") as f:
    for config_id in CONFIG_IDS:
        BASE_CMD = f"python {EXP_PATH}/main.py"
        cmd = BASE_CMD
        cmd += " --mode live"
        cmd += f" --config_id {config_id}"
        cmd += f" --save_dir {OUTPUT_DIR}"
        cmd += f" --worker_dir {OUTPUT_DIR}"

        f.writelines(cmd + "\n")
