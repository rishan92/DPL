#!/bin/bash

source ~/anaconda3/bin/activate nanoGPT-Bench

basedir=/home/janowski/PhD/nanoGPT-Bench/nanogpt_bench_examples/
workdir=/work/dlclarge1/janowski-nanogpt_bench/

cd "$basedir"

echo "base:""$basedir"
echo "work:""$workdir"
