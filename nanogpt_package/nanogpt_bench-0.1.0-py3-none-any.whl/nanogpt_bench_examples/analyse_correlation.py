import argparse
from pathlib import Path

import matplotlib.pyplot as plt
from scipy.stats import pearsonr

import nanogpt_bench
from nanogpt_bench.lib.core.search_space import get_config_grid

WORKER_DIR = Path(__file__).parent


def run(config_id=None, save_dir=None, worker_dir=None, mode="live"):

    n_embds = [4, 8, 16, 32, 64, 128]

    benchmark = nanogpt_bench.Benchmark(
        task="shakespeare_char",
        mode=mode,
        save_dir=save_dir,
        download=False if mode == "table" else True,
    )

    lcs = {"valid": {}, "train": {}}

    for config_id, config in enumerate(get_config_grid(search_space_id=0)):

        _config = config.get_dictionary()
        _config["vocab_size"] = 65

        if _config["n_embd"] != 4:
            continue

        lcs["valid"][config_id] = []
        lcs["train"][config_id] = []

        for n_embd in n_embds:

            _config["n_embd"] = n_embd

            results = benchmark(
                _config,
                config_id=config_id,
                worker_dir=worker_dir,
                global_seed=333,
                full_trajectory=True,
                debug=False,
            )

            lcs["train"][config_id].append(results[-1]["train-loss"])
            lcs["valid"][config_id].append(results[-1]["valid-loss"])

    print()

    _, ax = plt.subplots(2, 2, figsize=(10, 5))

    for i, (split, curves) in enumerate(lcs.items()):

        for curve in curves.values():
            ax[i, 0].plot(n_embds, curve)

        if i == 1:
            ax[i, 0].set_xlabel("n_embd")
        ax[i, 0].set_ylabel(f"{split} loss")
        ax[i, 0].set_xticks(n_embds)

    for i, (split, curves) in enumerate(lcs.items()):

        # Calculate Spearman rank correlation along the x-axis (n_embd) and plot
        ranks = {}
        for n_embd in n_embds:

            ranks[n_embd] = []

            for curve in curves.values():
                ranks[n_embd].append(curve[n_embds.index(n_embd)])

        corrs = []
        ranks_at_max = ranks[128]  # pd.DataFrame(ranks[128])  # .rank()
        for n_embd in n_embds:

            ranks_at_f = ranks[n_embd]  # pd.DataFrame(ranks[n_embd])  # .rank()
            corr, _ = pearsonr(ranks_at_max, ranks_at_f)
            corrs.append(corr)

        ax[i, 1].scatter(n_embds, corrs)
        ax[i, 1].set_ylim([-1, 1])
        ax[i, 1].set_ylabel(f"Pearson corr. on {split}")
        ax[i, 1].set_xticks(n_embds)

        if i == 1:
            ax[i, 1].set_xlabel("n_embd")

    plt.savefig("analysis/lcs_correlation.png")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_id", type=int, default=None)
    parser.add_argument("--save_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--worker_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--mode", type=str, default="table")
    args = parser.parse_args()
    run(
        config_id=args.config_id,
        save_dir=args.save_dir,
        worker_dir=args.worker_dir,
        mode=args.mode,
    )
