import nanogpt_bench
from nanogpt_bench.lib.core.search_space import get_config_id

benchmark = nanogpt_bench.Benchmark(
    task="shakespeare",
    mode="live",
    search_space_id=1,
)
# Use benchmark object to sample a random configuration.
# config = benchmark.sample_config()
# Alternatively, define configuration as a dictionary.
config = {
    "lr_max": 1e-5,
    "lr_min_percent": 0.01,
    "n_embd": 384,
    "warmup_percent": 0.1,
    "n_layer": 6,
    "n_head": 6,
    "vocab_size": 50304,
    "block_size": 512,
}

config_id = get_config_id(config, search_space_id=1)

print(f"Sampled configuration: {config}\n" f"Config ID: {config_id}")


# from nanogpt_bench.lib.core.search_space import get_config_grid
#
# config_grid = get_config_grid(search_space_id=1)
#
# ids = []
# for config in config_grid:
#     _config = config.get_dictionary()
#     config_id = get_config_id(_config, search_space_id=1)
#     if _config["n_embd"] != 48:
#         continue
#     ids.append(config_id)
#
# print(ids)
