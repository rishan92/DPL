import argparse
from pathlib import Path

import nanogpt_bench

WORKER_DIR = Path(__file__).parent


def run(config_id=None, save_dir=None, worker_dir=None, mode="table", task="openwebtext"):
    benchmark = nanogpt_bench.Benchmark(
        # task="shakespeare",
        task=task,
        mode=mode,
        save_dir=save_dir,
        download=False if mode == "table" or task == "openwebtext" else True,
        search_space_id=1,
    )
    # Use benchmark object to sample a random configuration.
    # config = benchmark.sample_config()
    # Alternatively, define configuration as a dictionary.
    config = {
        "lr_max": 0.0001,
        "lr_min_percent": 0.01,
        "n_embd": 384,
        "warmup_percent": 0.1,
        "n_layer": 6,
        "n_head": 6,
        "vocab_size": 50304,
        "block_size": 512,
        "max_epochs": 350,
    }
    # Or, use a configuration ID to sample a configuration from the grid.
    if config_id is not None:
        config = None

    results = benchmark(
        config,
        config_id=config_id,
        worker_dir=worker_dir,
        global_seed=333,
        epochs=350,
        debug=True,
    )

    print(f"Sampled configuration: {config}\n" f"Results: {results}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_id", type=int, default=None)
    parser.add_argument("--save_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--worker_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--mode", type=str, default="table")
    parser.add_argument("--task", type=str, default="openwebtext")
    args = parser.parse_args()
    run(
        config_id=args.config_id,
        save_dir=args.save_dir,
        worker_dir=args.worker_dir,
        mode=args.mode,
        task=args.task,
    )
