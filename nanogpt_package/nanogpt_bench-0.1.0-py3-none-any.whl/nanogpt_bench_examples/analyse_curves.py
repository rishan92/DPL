import argparse
from pathlib import Path

import matplotlib.pyplot as plt

import nanogpt_bench
from nanogpt_bench.lib.core.search_space import get_config_grid

WORKER_DIR = Path(__file__).parent


def run(config_id=None, save_dir=None, worker_dir=None, mode="live", metric="valid-loss"):
    benchmark = nanogpt_bench.Benchmark(
        task="shakespeare_char",
        mode=mode,
        save_dir=save_dir,
        download=False if mode == "table" else True,
    )

    for n_embd in [4, 8, 16, 32, 64, 128]:

        lcs = []
        for config in get_config_grid(search_space_id=0):

            _config = config.get_dictionary()

            if _config["n_embd"] != n_embd:
                continue

            _config["vocab_size"] = 65

            results = benchmark(
                _config,
                config_id=config_id,
                worker_dir=worker_dir,
                global_seed=333,
                full_trajectory=True,
                debug=False,
            )
            lcs.append([r[metric] for r in results])

        for lc in lcs:
            plt.plot(lc)

        plt.title(f"{metric} at {n_embd} embd")
        plt.xlabel("Epochs")
        plt.ylabel(f"{metric}")

        plt.savefig(f"analysis/{metric}_at_{n_embd}.png")
        plt.clf()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_id", type=int, default=None)
    parser.add_argument("--save_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--worker_dir", type=str, default=WORKER_DIR)
    parser.add_argument("--mode", type=str, default="table")
    parser.add_argument("--metric", type=str, default="valid-loss")
    args = parser.parse_args()
    run(
        config_id=args.config_id,
        save_dir=args.save_dir,
        worker_dir=args.worker_dir,
        mode=args.mode,
        metric=args.metric,
    )
