from pathlib import Path

import nanogpt_bench
from nanogpt_bench.lib.core.search_space import get_config_grid

WORKER_DIR = Path(__file__).parent

benchmark = nanogpt_bench.Benchmark(
    task="shakespeare_char",
    mode="table",
    save_dir=WORKER_DIR,
    download=False,
)

missing_ids = []
missing_epochs_ids = []
for i, config in enumerate(get_config_grid(search_space_id=0), start=0):

    _config = config.get_dictionary()

    try:
        results = benchmark(
            _config,
            worker_dir=WORKER_DIR,
            global_seed=333,
            full_trajectory=True,
        )
    except Exception as e:
        print(f"Sampled configuration: {i}. Results: FAILED")
        missing_ids.append(i)
    else:
        if len(results) < 50:
            print(
                f"Sampled configuration: {i}. Results recorded for: {len(results)} epochs"
            )
            missing_epochs_ids.append(i)

print(f"Missing IDs ({len(missing_ids)}): {missing_ids}")
print(f"Missing Epochs IDs ({len(missing_epochs_ids)}): {missing_epochs_ids}")
