import json
import logging
import os
import traceback
from pathlib import Path
from typing import Sequence

import ConfigSpace
import numpy as np
import torch

import nanogpt_bench.lib.core.search_space
import nanogpt_bench.lib.models.utils
import nanogpt_bench.lib.utils as util
import nanogpt_bench.lib.utils.naslib_logging as naslib_logging
from nanogpt_bench.data import get_dataloaders
from nanogpt_bench.lib.core.constants import Datasets, standard_task_metrics
from nanogpt_bench.lib.core.procs import train
from nanogpt_bench.lib.utils import AttrDict


def run_task(
    base_dir: Path,
    task_id: int,
    train_config: AttrDict,
    task: Datasets,
    data_dir: Path,
    local_seed: int | None = None,
    global_seed: int | None = None,
    debug: bool = True,
    logger: logging.Logger = None,
    config: Sequence[str] | None = None,
    config_id: int = 0,
    search_space_id: int = 0,
):
    rng = np.random.RandomState(np.random.Philox(seed=local_seed, counter=task_id))
    global_seed_gen = util.default_global_seed_gen(rng, global_seed)
    dir_tree = util.DirectoryTree(base_dir=base_dir, task_id=task_id, config_id=config_id)

    if logger is None:
        logger = naslib_logging.setup_logger(
            str(dir_tree.model_dir / "log.log"),
            name="nanogpt_bench",
        )

    task_metrics = AttrDict(
        util.attrdict_factory(metrics=standard_task_metrics, template=list)
    )

    # The timer-based interface is necessary to synchronize the model metric logger and checkpointer later.
    tasktimer = (
        util.SynchroTimer()
    )  # This timer must be set manually, but it still uses model_idx as time
    task_metric_logger = util.MetricLogger(
        dir_tree=dir_tree,
        metrics=task_metrics,
        set_type=util.MetricLogger.MetricSet.task,
        logger=logger,
        timer=tasktimer,
    )
    n_known_samples = len(task_metrics.ConfigIndex)
    tasktimer.adjust(previous_timestamp=n_known_samples)

    task_config = {
        "train_config": train_config,
        "dataset": task.value[0],
        "local_seed": local_seed,
        "global_seed": global_seed,
        "debug": debug,
        "config": config,
    }

    with open(dir_tree.task_config_file, "w") as fp:
        json.dump(task_config, fp, default=str)

    logger.setLevel(logging.DEBUG if debug else logging.INFO)

    config, curr_global_seed = nanogpt_bench.lib.core.search_space.config_sampler(
        global_seed_gen=global_seed_gen,
        config_id=config_id,
        search_space_id=search_space_id,
    )
    logger.info("Sampled new architecture.")
    logger.debug(f"{config}")

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    logger.debug(f"Training config {config_id} on device {str(device)}")

    # Data loading
    data_loaders, vocab_size = get_dataloaders(
        data_dir=data_dir,
        batch_size=train_config.batch_size,
        block_size=train_config.block_size,
        num_workers=0,
        device=device,
    )

    # As Configuration objects are not JSON serializable, we convert them to AttrDicts,
    # which are. Also, we add a bunch of stuff to override the default GPTConfig.
    if isinstance(config, ConfigSpace.Configuration):
        config = AttrDict(config.get_dictionary())

    # Either use the vocab size from the data meta-data file or the one from the default GPTConfig
    if vocab_size is not None:
        config.vocab_size = vocab_size

    # Model initialization
    model = nanogpt_bench.lib.models.utils.get_model(config=config)
    logger.debug(f"Model {config_id} initialized: {model}")
    logger.debug(f"Number of parameters: {model.get_num_params()}")
    logger.debug(f"Using vocab size {model.config.vocab_size}")
    logger.debug(f"Using block size {model.config.block_size}")

    transfer_devices = device.type != "cpu"
    if transfer_devices:
        logger.debug(f"Transferring model to device: {device}.")
        model = model.to(device)

    # Handle task-level metrics
    if config_id < n_known_samples:
        # This particular model has already been sampled once. Verify config and seed.
        assert task_metrics.global_seed[config_id - 1] == curr_global_seed, (
            f"There is a mismatch between the previously registered global seed used for evaluating the "
            f"model index {config_id} and the newly generated seed {curr_global_seed}"
        )
        if not task_metrics.config[config_id - 1] == config_id:
            logger.log(
                logging.WARNING,
                f"Task {task_id}, model {config_id}: Model config generation mismatch. Old model config: "
                f"{task_metrics.config[config_id - 1]}. Newly generated config: {config_id}",
            )
        logger.debug(f"Task {task_id}, model {config_id} has been previously sampled.")

    # A new model config has been sampled or has been queried for more epochs.
    task_metrics.ConfigIndex.append(config_id)
    task_metrics.config.append(config)
    task_metrics.global_seed.append(curr_global_seed)
    task_metrics.size_bytes.append(
        nanogpt_bench.lib.models.utils.count_parameters_in_bytes(model)
    )

    tasktimer.update(timestamp=config_id, force=True)
    task_metric_logger.log()
    logger.debug(f"Logged new sample for task {task_id}, model {config_id}.")

    # Actual model training and evaluation
    try:
        dir_tree.i = config_id

        if dir_tree.model_error_description_file.exists():
            os.remove(dir_tree.model_error_description_file)

        logger.debug(f"Setting seed to {curr_global_seed}")
        util.set_seed(curr_global_seed)

        train(
            model=model,
            data_loaders=data_loaders,
            train_config=train_config,
            dir_tree=dir_tree,
            logger=logger,
            transfer_devices=transfer_devices,
            device=device,
            debug=debug,
        )
    except Exception as e:
        naslib_logging.log_every_n_seconds(
            logging.INFO, "Architecture Training failed.", 15, name=logger.name
        )
        error_description = {
            "exception": traceback.format_exc(),
            "config": config,
            "global_seed": curr_global_seed,
        }
        with open(dir_tree.model_error_description_file, "w") as fp:
            json.dump(error_description, fp, indent=4)
        if debug:
            raise e
    else:
        # Clean-up after nominal program execution
        logger.info("Sampled architecture trained successfully.")

        del model  # Release memory
        dir_tree.config_id = (
            None  # Ensure that previously written data cannot be overwritten
        )

    # Clean up memory before terminating task
    del task_metrics
    del task_metric_logger
    del dir_tree
