"""
Constants used in the benchmarking framework.
"""
from dataclasses import dataclass
from enum import Enum


class Datasets(Enum):
    Shakespeare = "shakespeare"
    Shakespeare_char = "shakespeare_char"
    OpenWebText = "openwebtext"
    WMT2014_EN_GER = "wmt2014_en_ger"
    WMT2014_EN_FR = "wmt2014_en_fr"


# Metric DataFrame constant
class MetricDFIndexLevels(Enum):
    task_id = "TaskIndex"
    config_id = "ConfigIndex"
    epoch = "Epoch"


metricdf_column_level_names = ["MetricType", "MetricName"]
metricdf_index_levels = list(MetricDFIndexLevels.__members__.keys())

# Metric metadata constants
standard_task_metrics = [
    MetricDFIndexLevels.config_id.value,
    "config",
    "global_seed",
    "size_bytes",
]
standard_model_dataset_metrics = [
    "duration",
    "data_load_duration",
    "forward_duration",
    "loss",
    # "bleu",
]
extra_model_training_metrics = ["backprop_duration"]
standard_model_diagnostic_metrics = [
    "FLOPS",
    "latency",
    "runtime",
    "cpu_percent",
    "memory_ram",
    "memory_swap",
]

fidelity_types = {"n_embd": float, "epochs": float, "width_multiplier": float}
fidelity_params = tuple(fidelity_types.keys())

features = [
    "lr_max",
    "lr_min_percent",
    "n_embd",
    "warmup_percent",
    "vocab_size",
    "block_size",
    "n_head",
    "n_layer",
    "epoch",
]


@dataclass
class GPTConfig:
    # Model hyperparameters
    vocab_size: int = 50304  # GPT-2 vocab_size of 50257, padded up to the nearest multiple of 64 for efficiency
    block_size: int = None  # to be overridden by train config
    dropout: float = 0.0
    bias: bool = True  # True: bias in Linears and LayerNorms, like GPT-2. False: a bit better and faster

    # Training hyperparameters
    max_epochs: int = 350
    optimizer: str = "AdamW"
    lr_scheduler: str = "Cosine"
    gradient_clipping: float = 1.0
    weight_decay: float = 1e-1
    beta1: float = 0.9
    beta2: float = 0.98

    # Fidelity parameter
    n_embd: int = 384  # 768
    n_layer: int = 6  # 12
    n_head: int = 6  # 12

    # Hyperparameters to be optimized
    lr_max: float = 6e-4
    lr_min_percent: float = 0.1
    warmup_percent: float = 0.05
    # warmup_epochs: int = 0


@dataclass
class TrainConfig:
    epochs: int = 0  # to be overridden by benchmark call
    block_size: int = 1024  # 1024
    batch_size: int = 12
    split: bool = True
    disable_checkpointing: bool = False
    checkpoint_interval_seconds: int = 3600
    checkpoint_interval_epochs: int = 1
    config_id: int = -1
