from __future__ import annotations

import logging
import time

import psutil
import torch
import wandb

import nanogpt_bench.lib.core.constants as constants
import nanogpt_bench.lib.models.utils
import nanogpt_bench.lib.utils as util
import nanogpt_bench.lib.utils.naslib_logging as naslib_logging
from nanogpt_bench.lib.utils import AttrDict
from nanogpt_bench.lib.utils.optimizer import CosineAnnealingLR  # , Optimizers


def construct_scheduler(optimizer: torch.optim.Optimizer, model: torch.nn.Module):
    # optim_type = Optimizers.__members__[model.config.optimizer]
    # optimizer = optim_type.construct(model, model.config)

    scheduler = CosineAnnealingLR(
        optimizer,
        warmup_epochs=int(model.config.max_epochs * model.config.warmup_percent),
        epochs=model.config.max_epochs,
        T_max=model.config.max_epochs,
        eta_min=model.config.lr_max * model.config.lr_min_percent,
    )

    return scheduler


def _main_proc(
    model: torch.nn.Module,
    data_loader,
    optimizer: torch.optim.Optimizer,
    scheduler: CosineAnnealingLR,
    logger: logging.Logger = None,
    mode: str = "train",
    device: torch.device | str = "cpu",
    epoch_metrics: dict[str, list] = None,
    debug: bool = False,
):
    if logger is None:
        logger = logging.getLogger(__name__)

    # if debug:
    #     wandb.watch(model, log_freq=100)
    if mode == "train":
        model.train()
    elif mode == "valid":
        model.eval()
    else:
        raise ValueError(f"Invalid mode {mode}")

    # Setup control flags
    transfer_devices = device.type != "cpu"
    train_model = mode == "train"

    #  Setup metrics
    extra_metrics = []

    if transfer_devices:
        extra_metrics.append("data_transfer_duration")

    if train_model:
        extra_metrics.append("backprop_duration")

    metrics = util.attrdict_factory(
        metrics=constants.standard_model_dataset_metrics + extra_metrics
    )

    diverged = False
    data_load_start_time = time.time()
    # TODO: remember that one epoch is 1k random samples
    n_steps = 1000  # len(data_loader)
    # logger.debug(
    #     f"One epoch is:"
    #     f" {n_steps} x {data_loader.batch_size}"
    #     f" = {n_steps * data_loader.batch_size} samples"
    # )

    for step in range(n_steps):

        inputs, targets = data_loader.dataset.__getitem__(
            ix=None, batch_size=data_loader.batch_size, pin_memory=True, device=device
        )

        metric_weight = inputs.size(0)
        start_time = time.time()
        metrics.data_load_duration.update(
            start_time - data_load_start_time, metric_weight
        )

        if train_model:
            scheduler.update(None, 1.0 * step / n_steps)
            optimizer.zero_grad()

        if transfer_devices:
            inputs = inputs.to(device)
            targets = targets.to(device)
            metrics.data_transfer_duration.update(time.time() - start_time, metric_weight)

        # # Forward Pass
        forward_start_time = time.time()
        logits, loss = model(inputs, targets)
        metrics.forward_duration.update(time.time() - forward_start_time, metric_weight)

        # Backward Pass
        if train_model:
            backprop_start_time = time.time()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), max_norm=model.config.gradient_clipping, norm_type=2
            )
            optimizer.step()
            end_time = time.time()
            metrics.backprop_duration.update(
                end_time - backprop_start_time, metric_weight
            )
        else:
            end_time = time.time()

        # Bookkeeping
        metrics.duration.update(end_time - start_time, metric_weight)
        metrics.loss.update(loss.detach().cpu().data.item(), metric_weight)
        # TODO: calculate bleu
        # acc = naslib_utils.accuracy(logits.detach().cpu(), labels.detach().cpu(), topk=(1,))[0]
        # metrics.bleu.update(bleu.data.item(), metric_weight)

        # Debugging, logging and clean-up
        naslib_logging.log_every_n_seconds(
            logging.DEBUG,
            f"[Minibatch {step + 1}/{n_steps}] Mode: {mode} Avg. Loss: {metrics.loss.avg:.5f}, "
            # f"Avg. Accuracy: {metrics.bleu.avg:.5f},"
            f" Avg. Time per step: {metrics.duration.avg}",
            n=30,
            name=logger.name,
        )

        if debug:
            wandb.log(
                {
                    "lr": scheduler.get_lr()[0],
                    f"batch_loss_{mode}": loss.detach().cpu(),
                }
            )

        if torch.isnan(loss):
            logger.debug(
                f"Encountered NaN loss."
                f" Predictions: {logits}\n\n"
                f"Expected labels: {targets}\n\n"
                f"Loss: {loss}"
            )
            diverged = True

        if diverged:
            return 0, True

        data_load_start_time = time.time()

        if step >= n_steps:
            break

    n = 0  # Number of individual data points processed
    for key, value in metrics.items():
        epoch_metrics[key].append(
            value.avg
        )  # Metrics are recorded as averages per data-point for each epoch
        n = max([n, value.cnt])  # value.cnt is expected to be constant

    return n, False


def train(
    model: torch.nn.Module,
    data_loaders,
    train_config: AttrDict,
    dir_tree: util.DirectoryTree,
    logger: logging.Logger,
    transfer_devices: bool = False,
    device: torch.device | str = "cpu",
    debug: bool = False,
):
    start_time = time.time()
    latency = util.AverageMeter()

    # Initialization calls to psutil
    _ = psutil.cpu_percent()
    _ = psutil.virtual_memory()
    _ = psutil.swap_memory()

    train_queue = data_loaders["train"]
    valid_queue = data_loaders["valid"]

    extra_metrics = ["data_transfer_duration" if transfer_devices else None]
    dataset_metrics = constants.standard_model_dataset_metrics + extra_metrics
    model_metrics = AttrDict(
        {
            "train": util.attrdict_factory(
                metrics=dataset_metrics + constants.extra_model_training_metrics,
                template=list,
            ),
            "valid": util.attrdict_factory(metrics=dataset_metrics, template=list),
            "diagnostic": util.attrdict_factory(
                metrics=constants.standard_model_diagnostic_metrics, template=list
            ),
        }
    )

    optimizer = model.configure_optimizers(
        weight_decay=model.config.weight_decay,
        learning_rate=model.config.lr_max,
        betas=(model.config.beta1, model.config.beta2),
        device_type=device,
    )
    scheduler = construct_scheduler(optimizer, model)
    logger.debug(
        f"Initialized optimizer {optimizer.__class__.__name__}"
        f" and scheduler {scheduler.__class__.__name__}"
    )

    old_chkpt_runtime = 0.0
    old_chkpt_epoch_idx = -1
    timer = util.SynchroTimer(
        ping_interval_time=train_config.checkpoint_interval_seconds,
        ping_interval_epochs=train_config.checkpoint_interval_epochs,
    )

    if (
        train_config.checkpoint_interval_seconds is not None
        and train_config.checkpoint_interval_epochs is not None
    ):
        logger.log(
            logging.WARNING,
            "Checkpoint logging at regular intervals of time as well as epochs has been "
            "enabled simultaneously (shorter is chosen).",
        )

    if not train_config.disable_checkpointing:
        checkpoint = util.Checkpointer(
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            dir_tree=dir_tree,
            logger=logger,
            map_location=device,
            timer=timer,
        )
        old_chkpt_runtime = checkpoint.runtime
        old_chkpt_epoch_idx = checkpoint.last_epoch

    model_metrics_logger = util.MetricLogger(
        dir_tree=dir_tree,
        metrics=model_metrics,
        set_type=util.MetricLogger.MetricSet.model,
        logger=logger,
        timer=timer,
    )

    if debug:
        wandb.init(
            project="nanopgt_bench_owt_1",
            id=str(train_config.config_id),
            dir=dir_tree.model_wandb_dir,
            resume="allow",
            reinit=True,
        )

    if old_chkpt_runtime != model_metrics_logger.elapsed_runtime:
        raise RuntimeError(
            f"The Checkpoint and Metrics Log are out of sync. The latest checkpoint has the timestamp "
            f"{old_chkpt_runtime} while the latest metrics log has the timestamp "
            f"{model_metrics_logger.elapsed_runtime}. Use the data integrity verification tools to "
            f"resolve this. Note that this may cause some loss of data."
        )

    timer.adjust(previous_timestamp=old_chkpt_runtime, last_epoch=old_chkpt_epoch_idx)

    train_size = valid_size = 0

    for epoch in range(old_chkpt_epoch_idx + 1, train_config.epochs):
        scheduler.update(epoch, 0.0)

        # Train
        n, diverged = _main_proc(
            model=model,
            data_loader=train_queue,
            optimizer=optimizer,
            scheduler=scheduler,
            mode="train",
            device=device,
            epoch_metrics=model_metrics.train,
            logger=logger,
            debug=debug,
        )
        if diverged:
            break
        train_size = max([train_size, n])

        # Validate
        n, _ = _main_proc(
            model=model,
            data_loader=valid_queue,
            optimizer=optimizer,
            scheduler=scheduler,
            mode="valid",
            device=device,
            epoch_metrics=model_metrics.valid,
            logger=logger,
            debug=debug,
        )

        valid_size = max([valid_size, n])
        latency.update(model_metrics.valid.forward_duration[-1], valid_size)

        # Logging
        naslib_logging.log_every_n_seconds(
            logging.DEBUG,
            f"[Epoch {epoch + 1}/{train_config.epochs}] "
            + f"Avg. Train Loss: {model_metrics.train.loss[-1]:.5f}, "
            +
            # f"Avg. Train Acc: {model_metrics.train.acc[-1]:.5f},\n" +
            f"Avg. Valid Loss: {model_metrics.valid.loss[-1]:.5f},\n " +
            #  f"Avg. Valid Acc: {model_metrics.valid.acc[-1]:.5f},\n" +
            f"Time Elapsed: {time.time() - start_time}",
            15,
            name=logger.name,
        )

        if debug:
            wandb.log(
                {
                    "train_loss": model_metrics.train.loss[-1],
                    "valid_loss": model_metrics.valid.loss[-1],
                    "epoch": epoch + 1,
                }
            )

        # Checkpointing
        # Add a one-time offset to the runtime in case an old checkpoint was loaded
        effective_elapsed_runtime = time.time() - start_time + old_chkpt_runtime
        first_epoch = epoch == 0
        last_epoch = epoch == train_config.epochs - 1
        timer.update(
            timestamp=effective_elapsed_runtime,
            curr_epoch=epoch,
            force=first_epoch or last_epoch,
        )
        if not train_config.disable_checkpointing:
            checkpoint()

        # No need to calculate this again everytime, changes reflect checkpointing-relevant differences.
        flops = nanogpt_bench.lib.models.utils.get_model_flops(model)
        model_metrics.diagnostic.FLOPS.append(flops)

        model_metrics.diagnostic.latency.append(latency.avg)
        model_metrics.diagnostic.runtime.append(effective_elapsed_runtime)
        model_metrics.diagnostic.cpu_percent.append(psutil.cpu_percent())
        model_metrics.diagnostic.memory_ram.append(psutil.virtual_memory().available)
        model_metrics.diagnostic.memory_swap.append(psutil.swap_memory().free)
        model_metrics_logger.log()

        if diverged:
            raise RuntimeError(f"Model training has diverged after {epoch} epochs.")

    if not train_config.disable_checkpointing:
        del checkpoint
    del model_metrics_logger

    return model_metrics
