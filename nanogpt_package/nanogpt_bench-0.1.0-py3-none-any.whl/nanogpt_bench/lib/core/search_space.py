from __future__ import annotations

import ConfigSpace
import ConfigSpace.util as util


def get_search_space(search_space_id):

    config_space = None

    if search_space_id == 0:
        config_space = ConfigSpace.ConfigurationSpace("nanogpt_bench")
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "n_embd",
                sequence=[4, 8, 16, 32, 64, 128],
                # sequence=[4, 8, 16, 32, 64, 128, 192, 384, 768],
                # default_value=2,
                # meta="Embedding dimension (default: 2)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "n_layer",
                value=4,
                # default_value=4,
                # meta="Number of attention heads and layers (default: 4)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "n_head",
                value=4,
                # default_value=4,
                # meta="Number of attention heads and layers (default: 4)"
            )
        )
        # The vocabulary size is fixed to 65 for the Shakespeare character-level dataset.
        # For other datasets, it is equal to GPT2 tokenization size.
        # Kept here for convenience, will be overridden in the benchmark (train_config)
        # based on dataset meta-information.
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "vocab_size",
                value=65,
                # default_value=65,
                # meta="Vocabulary size (default: 65)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "block_size",
                value=512,
                # default_value=512,
                # meta="Context block size (default: 512)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "lr_max",
                sequence=[1e-5, 1e-4, 1e-3, 1e-2],
                # default_value=1e-4,
                # meta="Maximum learning rate (default: 1e-4)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "lr_min_percent",
                sequence=[1e-2, 1e-1],
                # default_value=1e-1,
                # meta="Learning rate lower bound: factor to multiply the lr_max by (default: 1e-1)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "warmup_percent",
                sequence=[0.05, 0.10, 0.15, 0.2, 0.25],
                # default_value=0.05,
                # meta="Factor to multiply the number of epochs by to determine the warmup epochs (default: 0.05)"
            )
        )
    elif search_space_id == 1:
        config_space = ConfigSpace.ConfigurationSpace("nanogpt_bench")
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "max_epochs",
                value=350,
                # default_value=350,
                # meta="Maximum number of epochs (default: 350)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "n_embd",
                sequence=[6, 12, 24, 48, 96, 192, 384, 768],
                # default_value=6,
                # meta="Embedding dimension (default: 6)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "n_layer",
                value=6,
                # default_value=6,
                # meta="Number of attention heads and layers (default: 6)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "n_head",
                value=6,
                # default_value=6,
                # meta="Number of attention heads and layers (default: 6)"
            )
        )
        # The vocabulary size is fixed to 65 for the Shakespeare character-level dataset.
        # For other datasets, it is equal to GPT2 tokenization size.
        # Kept here for convenience, will be overridden in the benchmark (train_config)
        # based on dataset meta-information.
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "vocab_size",
                value=50304,
                # default_value=50304,
                # meta="Vocabulary size (default: 50304)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "block_size",
                value=512,
                # default_value=512,
                # meta="Context block size (default: 512)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "lr_max",
                sequence=[1e-5, 1e-4, 1e-3],
                # default_value=1e-4,
                # meta="Maximum learning rate (default: 1e-4)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.Constant(
                "lr_min_percent",
                value=1e-2,
                # default_value=1e-1,
                # meta="Learning rate lower bound: factor to multiply the lr_max by (default: 1e-1)"
            )
        )
        config_space.add_hyperparameter(
            ConfigSpace.OrdinalHyperparameter(
                "warmup_percent",
                sequence=[0.10, 0.2],
                # default_value=0.05,
                # meta="Factor to multiply the number of epochs by to determine the warmup epochs (default: 0.05)"
            )
        )

    return config_space


def get_config_grid(search_space_id):

    grid = util.generate_grid(get_search_space(search_space_id))
    grid = list(
        filter(
            lambda config: config.get("n_embd") % config.get("n_head") == 0,
            grid,
        )
    )

    return grid


def get_config_id(config: ConfigSpace.Configuration | dict, search_space_id: int = 0):
    if isinstance(config, ConfigSpace.Configuration):
        config = config.get_dictionary()

    for config_id, _config in enumerate(get_config_grid(search_space_id)):
        if config == _config.get_dictionary():
            return config_id
    raise ValueError(f"Config: {config} not found in config grid")


def config_sampler(
    global_seed_gen, config_id: int, search_space_id: int = 0
) -> tuple[ConfigSpace.Configuration, int]:

    return get_config_grid(search_space_id)[config_id], next(global_seed_gen)
