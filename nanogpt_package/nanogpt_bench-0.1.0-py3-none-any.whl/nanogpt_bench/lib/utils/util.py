"""
This file includes utility functions for the nanogpt_bench library heavily-based
on JAHS-Bench-201 repository, at https://github.com/automl/jahs_bench_201
"""

from __future__ import annotations

import enum
import logging
import random
from itertools import repeat
from pathlib import Path
from typing import Any, Callable, Hashable, Iterable, Optional, TypeAlias, Union

import numpy as np
import pandas as pd
import torch

import nanogpt_bench.lib.core.constants as constants
from nanogpt_bench.lib.utils.optimizer import CosineAnnealingLR

MAP_LOCATION: TypeAlias = Optional[
    Union[Callable[[torch.Tensor, str], torch.Tensor], torch.device, str, dict[str, str]]
]


def set_seed(seed):
    """
    Set the seeds for all used libraries.
    """
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.enabled = True
        torch.backends.cudnn.deterministic = True
        torch.cuda.manual_seed_all(seed)

    torch.backends.cuda.matmul.allow_tf32 = True  # allow tf32 on matmul
    torch.backends.cudnn.allow_tf32 = True  # allow tf32 on cudnn


class AttrDict(dict):
    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError as e:
            raise AttributeError from e

    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class AverageMeter:
    def __init__(self):
        self.reset()

    def reset(self):
        self.avg = 0
        self.sum = 0
        self.cnt = 0

    def update(self, val, n=1):
        self.sum += val * n
        self.cnt += n
        self.avg = self.sum / self.cnt  # pylint: disable=attribute-defined-outside-init


def attrdict_factory(
    metrics: list[str] | None = None, template: Callable = AverageMeter
) -> AttrDict:
    """Convenience function for generating an AttrDict object with arbitrary keys initialized using a factory
    function, essentially an AttrDict extension to collections.defaultdict. 'metrics' is a list of keys (usually
    strings) and the initial value of these keys can optionally be set by passing an object factory to the parameter
    'template', which defaults to naslib.utils.utils.AverageMeter."""

    metrics = AttrDict({m: template() for m in metrics} if metrics else {})
    return metrics


def default_global_seed_gen(
    rng: np.random.RandomState | None = None, global_seed: int | None = None
) -> Iterable[int]:
    if global_seed is not None:
        return global_seed if isinstance(global_seed, Iterable) else repeat(global_seed)
    elif rng is not None:

        def seeds():
            while True:
                yield rng.randint(0, 2**32 - 1)

        return seeds()
    else:
        raise ValueError(
            "Cannot generate sequence of global seeds when both 'rng' and 'global_seed' are None."
        )


class DirectoryTree:
    """A very simply class that translates a base directory into various relevant output directories. Useful for
    maintaining consistency across the code.
    The following directory structure is used by DirectoryTree:
    <base_dir>
    |--> <task_id>/
    |    |--> metrics/
    |    |    |--> <elapsed_runtime>.pkl.gz    <-- these are metric DataFrame files
    |    |--> models/
    |    |    |--> <model_idx>/
    |    |    |    |--> metrics/
    |    |    |    |    |--> <elapsed_runtime>.pkl.gz    <-- these are metric DataFrame files
    |    |    |    |--> checkpoints/
    |    |    |    |    |--> <elapsed_runtime>.pt    <-- these are checkpoint files
    """

    def __init__(
        self,
        base_dir: Path,
        task_id: int | None = None,
        config_id: int | None = None,
        read_only: bool = False,
    ):
        """
        The DirectoryTree enables a fixed, pre-determined directory sub-tree to be made and easily traversed at the
        given base directory, 'basedir'. 'taskid' and 'model_idx' are optional integers that can be changed and
        reassigned any time in order to generate the respective branch of the tree. Setting 'read_only' to True allows
        the tree to assume that no new directories need to be created if they don't exist and raise an Error if such an
        attempt to access such directory is made.
        """
        self.base_dir = base_dir.resolve()
        assert self.base_dir.exists() and self.base_dir.is_dir(), (
            f"The base directory and its parent directory tree must be created beforehand. Given base directory "
            f"either does not exist or is not a directory: {str(self.base_dir)}"
        )
        self.read_only = read_only
        # Setting these to int values also creates the appropriate directories if read_only is False
        self.task_id = task_id
        self.config_id = config_id

    @property
    def task_id(self) -> int:
        return self._taskid

    @task_id.setter
    def task_id(self, new_id: int | None):
        if new_id is not None:
            assert isinstance(
                new_id, int
            ), f"Task ID must be an integer, was given {type(new_id)}"
            self._taskid = new_id
            if self.read_only:
                return
            if not self.task_dir.exists():
                self.task_dir.mkdir(parents=True)
            if not self.task_metrics_dir.exists():
                self.task_metrics_dir.mkdir(parents=True)
            if not self.task_models_dir.exists():
                self.task_models_dir.mkdir(parents=True)
        else:
            self._taskid = None

    @property
    def config_id(self) -> int:
        return self._config_id

    @config_id.setter
    def config_id(self, new_index: int | None):
        if new_index is not None:
            assert isinstance(
                new_index, int
            ), f"Model index must be an integer, was given {type(new_index)}"
            self._config_id = new_index
            if self.read_only:
                return
            subdirs = [
                self.model_dir,
                self.model_metrics_dir,
                self.model_checkpoints_dir,
                self.model_wandb_dir,
            ]
            for subdir in subdirs:
                if not subdir.exists():
                    subdir.mkdir(parents=True)
        else:
            self._config_id = None

    @property
    def task_dir(self) -> Path:
        return self.base_dir / str(self.task_id)

    @property
    def task_config_file(self) -> Path:
        return self.task_dir / "task_config.json"

    @property
    def task_metrics_dir(self) -> Path:
        return self.task_dir / "metrics"

    @property
    def task_models_dir(self) -> Path:
        return self.task_dir / "models"

    @property
    def model_dir(self) -> Path:
        assert (
            self.config_id is not None
        ), "A valid model index needs to be set before the relevant model level subtree can be accessed."
        return self.task_models_dir / str(self.config_id)

    @property
    def model_metrics_dir(self) -> Path:
        return self.model_dir / "metrics"

    @property
    def model_checkpoints_dir(self) -> Path:
        return self.model_dir / "checkpoints"

    @property
    def model_wandb_dir(self) -> Path:
        return self.model_dir / "wandb_logs"

    @property
    def model_error_description_file(self) -> Path:
        return self.model_dir / "error_description.json"

    @property
    def existing_tasks(self) -> list[Path] | None:
        return (
            None
            if not self.base_dir.exists()
            else [d for d in self.base_dir.iterdir() if d.is_dir()]
        )

    @property
    def existing_models(self) -> list[Path]:
        return (
            None
            if not self.task_models_dir.exists()
            else [d for d in self.task_models_dir.iterdir() if d.is_dir()]
        )


class MetricLogger:
    """
    Holds a set of metrics, information about where they are to be logged, the frequency at which they should be
    logged as well as some functionality to convert any given set of metrics into a pandas DataFrame. Consult
    DirectoryTree for a breakdown of how the file structure is organized. A SynchroTimer object needs to be passed to
    the initializer argument 'timer' in order to enable logging functionality. Without it, a MetricLogger object can
    only be used in 'read-only' mode.
    """

    @enum.unique
    class MetricSet(enum.Enum):
        """Defines uniquely recognized sets of metrics that are handled slightly differently from the norm."""

        model = enum.auto()
        task = enum.auto()
        default = enum.auto()

    def __init__(
        self,
        dir_tree: DirectoryTree,
        metrics: dict,
        timer: SynchroTimer | None = None,
        set_type: MetricSet = MetricSet.default,
        logger: logging.Logger = None,
        where: Path = None,
        safe_load: bool = True,
    ):
        """
        Setup a MetricLogger instance.
        :param dir_tree: DirectoryTree
            An instance of DirectoryTree that has already been initialized with the parameters appropriate for usage
            with this object, i.e. base directory, taskid and model index depending on which level of the tree this
            MetricLogger is intended to interface with.
        :param metrics: dict-like
            A dict-like object that will store the actual metric data. This object can be initialized with keys and no
            data before being passed to the MetricLogger, in which case the data will be filled in by loading it from
            disk.
        :param timer: SynchroTimer
            Used to coordinate the timing of saving metrics to disk with other parts of the code.
        :param set_type: Enum
            One of MetricLogger.MetricSet to indicate which level of the directory this logger will be interfacing with.
        :param logger: logging.Logger
            Used to generate log messages. Optional.
        :param where: Path
            An optional Path to a directory containing *.pkl.gz files, which should be compatible pickled Pandas
            DataFrames used to initialize the metrics dict. If None, the directory is read from the 'dir_tree'.
        :param safe_load: bool
            If True (default), failing to load the latest metrics log raises a RuntimeError. Otherwise, the next most
            recent readable metrics log is used instead.
        """
        self.dir_tree = dir_tree
        self.metrics = metrics
        self.timer = timer
        self.set_type = set_type
        self.logger = logger if logger is not None else logging.getLogger(__name__)
        self.elapsed_runtime = (
            0.0 if self.timer is None else self.timer.previous_timestamp
        )
        self.resume_latest_saved_metrics(where=where, safe_load=safe_load)

    @property
    def timer(self) -> SynchroTimer:
        return self._timer

    @timer.setter
    def timer(self, new_timer: SynchroTimer):
        if new_timer is None:
            self._timer = None
        elif not isinstance(new_timer, SynchroTimer):
            raise ValueError(
                f"Checkpointer requires a valid instance of SynchroTimer, cannot set timer to "
                f"{type(new_timer)}."
            )
        else:
            self._timer = new_timer
            self._timer_id = self._timer.register_new_listener()

    @property
    def _signal(self):
        return False if self.timer is None else self.timer.ping(self._timer_id)

    @classmethod
    def _nested_dict_to_df(cls, nested: dict | None) -> pd.DataFrame:
        """Given a nested dict of dicts, use each level of the nested keys as column index levels in a pandas
        MultiIndex and convert the entire data structure into a pandas DataFrame. Note that any item that is not a dict
        will be considered to be a leaf node in the nested dict structure, therefore, any iterables will be directly
        converted into columns. Care should be taken to make sure that such iterables are of an appropriate length.
        Single data items at each level will only be copied over to as many indices as the length of the longest
        iterable at that level."""

        assert isinstance(
            nested, dict
        ), f"Expected input to be a possibly nested dictionary, received {type(nested)}."

        index = None
        new_df = {}
        singles = {}
        for k, v in nested.items():
            if isinstance(v, dict):
                new_df[k] = cls._nested_dict_to_df(v)
            elif isinstance(v, Iterable):
                new_df[k] = pd.Series(v)
            else:
                singles[k] = v
                continue
            if index is None:
                index = new_df[k].index
                # new_df = pd.DataFrame(index=vdf.index)
        if new_df:
            new_df = pd.concat(
                new_df, axis=1
            )  # Create new level in columns MultiIndex or promote Index to MultiIndex
            new_df = new_df.assign(**singles)
        else:
            new_df = pd.DataFrame(singles, index=[0])

        return new_df

    @classmethod
    def _df_to_nested_dict(cls, df: pd.DataFrame) -> dict:
        """Given a DataFrame, attempts to convert it into a nested dict. This is intended to be the inverse of
        _nested_dict_to_df() and therefore only intended to work with DataFrame objects that were originally created by
        that function."""

        metrics_dict = AttrDict()
        for k in df.columns.unique(0):
            if isinstance(df[k], pd.Series):
                metrics_dict[k] = df[k].to_list()
            else:
                metrics_dict[k] = cls._df_to_nested_dict(df[k])

        return metrics_dict

    @classmethod
    def _handle_model_metric_dict(cls, metrics: dict) -> pd.DataFrame:
        df = cls._nested_dict_to_df(metrics)
        assert isinstance(
            df, pd.DataFrame
        ), f"This function should only be used with a DataFrame, not {type(df)}"
        assert isinstance(
            df.index, pd.Index
        ), f"Expected the model-level metrics DataFrame index to be an Index, not {type(df.index)}"
        assert isinstance(
            df.columns, pd.MultiIndex
        ), f"Expected the model-level metrics DataFrame columns to be a MultiIndex, not {type(df.columns)}"
        assert df.columns.nlevels == len(constants.metricdf_column_level_names), (
            f"Expected the model-level metrics DataFrame to have exactly {len(constants.metricdf_column_level_names)} levels "
            f"in the columns MultiIndex, got {df.columns.nlevels}. Consult tabular_sampling.lib.constants for more "
            f"details about the expected structure."
        )

        df.index = df.index.set_names([constants.MetricDFIndexLevels.epoch.value]) + 1
        df.columns.set_names(constants.metricdf_column_level_names, inplace=True)
        return df

    @classmethod
    def _handle_task_metric_dict(cls, metrics: dict) -> pd.DataFrame:
        configs = pd.DataFrame(metrics["config"]).to_dict()
        configs = {
            k: list(v.values()) for k, v in configs.items()
        }  # Convert list of dicts to dict of lists
        df = cls._nested_dict_to_df({**metrics, **{"config": configs}})

        assert isinstance(
            df, pd.DataFrame
        ), f"This function should only be used with a DataFrame, not {type(df)}"
        assert isinstance(
            df.index, pd.Index
        ), f"Expected the task-level metrics DataFrame index to be an Index, was {type(df.index)}"
        assert isinstance(
            df.columns, pd.MultiIndex
        ), f"Expected the task-level metrics DataFrame columns to be a MultiIndex, not {type(df.columns)}"
        assert df.columns.nlevels == 2, (
            f"Expected the task-level metrics DataFrame to have exactly 2 levels in the columns MultiIndex, got "
            f"{df.columns.nlevels}"
        )

        return df

    @property
    def _metric_set_dict_handlers(self):
        return {
            MetricLogger.MetricSet.model: self._handle_model_metric_dict,
            MetricLogger.MetricSet.task: self._handle_task_metric_dict,
            MetricLogger.MetricSet.default: self._nested_dict_to_df,
        }

    @classmethod
    def _handle_task_metric_df(cls, df: pd.DataFrame) -> dict:
        # Handle model configs specially since it's the only column index that uses a MultiIndex and needs to be
        # converted to a list of dicts format.
        configs = list(df["config"].transpose().to_dict().values())
        # The following is necessary to undo the automatic conversion of nested dicts to MultiIndex columns.
        other_cols = df.columns.unique(0).difference(["config"])
        metric_dict = cls._df_to_nested_dict(df[other_cols].droplevel(1, axis=1))
        metric_dict["config"] = configs

        return metric_dict

    @property
    def _metric_set_df_handlers(self):
        return {
            MetricLogger.MetricSet.model: self._df_to_nested_dict,
            MetricLogger.MetricSet.task: self._handle_task_metric_df,
            MetricLogger.MetricSet.default: self._df_to_nested_dict,
        }

    def _generate_df(self) -> pd.DataFrame:
        """Converts the currently stored dict of metrics into a Pandas DataFrame ready for being saved to disk."""

        metric_df = self._metric_set_dict_handlers[self.set_type](self.metrics)
        return metric_df

    @property
    def _metric_set_to_log_directory(self):
        return {
            MetricLogger.MetricSet.model: "model_metrics_dir",
            MetricLogger.MetricSet.task: "task_metrics_dir",
            MetricLogger.MetricSet.default: "basedir",
        }

    @property
    def log_directory(self):
        return getattr(self.dir_tree, self._metric_set_to_log_directory[self.set_type])

    def log(self, force: bool = False, where: Path | None = None):
        if self.timer is None:
            raise RuntimeError(
                "The log functionality of MetricLogger is enabled only when a valid timer has been set."
            )
        if self._signal or force:
            elapsed_runtime = self.timer.previous_timestamp
            df = self._generate_df()
            pth = where if where is not None else self.log_directory
            df.to_pickle(pth / f"{elapsed_runtime}.pkl.gz")
            self.elapsed_runtime = elapsed_runtime
            self.logger.info(f"Logged metrics at {str(pth)}")

    @classmethod
    def _extract_runtime_from_filename(cls, f: Path) -> float:
        return float(f.name.rstrip(".pkl.gz"))

    @classmethod
    def get_sorted_metric_paths(cls, pth: Path, ascending: bool = True) -> list[Path]:
        # pylint: disable=unnecessary-lambda
        latest = sorted(
            pth.rglob("*.pkl.gz"),
            key=lambda f: cls._extract_runtime_from_filename(f),
            reverse=not ascending,
        )
        return latest

    @classmethod
    def _load_metrics_log(
        cls,
        pths: Path | list[Path],
        safe_load: bool | None = True,
        get_path: bool = False,
    ) -> pd.DataFrame | None | tuple[pd.DataFrame | None, Path]:
        """Attempts to load a metrics log from either a single Path or a list of Paths, attempting each one in the
        order they occur. If 'safe_load' is set to False, the first metrics log in the list that is readable from disk
        is loaded. It is set to True by default - i.e. if the first metrics log cannot be loaded, a RuntimeError is
        raised."""

        if isinstance(pths, Path):
            pths = [pths]

        metric_df = None
        pth = None
        for pth in pths:
            try:
                metric_df = pd.read_pickle(pth)
            except Exception as e:
                if safe_load:
                    raise RuntimeError(
                        f"Could not safely load metric DataFrame at {pth}"
                    ) from e

                cls.logger.info(
                    f"Found possibly corrupt metric DataFrame at {pth}, reverting to an earlier "
                    f"checkpoint."
                )
            else:
                break

        return (metric_df, pth) if get_path else metric_df

    def resume_latest_saved_metrics(
        self, where: Path | None = None, safe_load: bool | None = True
    ):
        """Used in conjunction with the corresponding method of Checkpointer to resume model training and evaluation
        from where it was left off. If 'safe_load' is set to False, the most recent metric data that is readable from
        disk is loaded. Be careful with this setting - it is possible for the loaded checkpoint data and metrics data
        to be out of sync in such a scenario. It is set to True by default - i.e. if the latest metrics DataFrame
        cannot be loaded, an error is raised."""

        pth = where if where is not None else self.log_directory
        latest = self.get_sorted_metric_paths(pth=pth, ascending=False)
        metric_df, dfpth = self._load_metrics_log(
            pths=latest, safe_load=safe_load, get_path=True
        )

        if metric_df is None:
            self.logger.info(
                f"No valid pre-existing metric DataFrames found at {str(pth)}."
            )
            return

        loaded_metrics = self._metric_set_df_handlers[self.set_type](metric_df)
        for k in self.metrics.keys():
            self.metrics[k] = loaded_metrics[k]

        self.elapsed_runtime = self._extract_runtime_from_filename(dfpth)


class SynchroTimer:
    """A very simply class whose sole purpose is to provide a share-able object and interface so that multiple other
    pieces of code (such as Checkpointer and MetricLogger instances) can consult the same timing related logic. It
    handles the preparation of a signal based on the configuration of time/epoch frequency. Listeners that have been
    registered with a SynchroTimer object can then query it anytime to know if the signal has been prepared. This is
    by no means intended to be used for multi-process signal passing!"""

    previous_timestamp: float
    last_epoch: int
    ping_interval_time: float
    ping_interval_epochs: float
    _signal: bool
    _listeners: dict[Any, bool]

    def __init__(
        self, ping_interval_time: float = None, ping_interval_epochs: float = None
    ):
        """Setting either of the two interval types to None disables updates to the signal logic based on that
        property. It is thus possible to create a SynchroTimer object which can only generate signals at arbitrary
        intervals when manually asked to do so (see SynchroTimer.update())."""
        self.ping_interval_time = ping_interval_time
        self.ping_interval_epochs = ping_interval_epochs
        self.previous_timestamp = 0.0
        self.last_epoch = -1
        self._listeners = {}
        self._signal = False

    def adjust(
        self, previous_timestamp: float | None = None, last_epoch: int | None = None
    ):
        """Sets the elapsed time and epochs without causing a signal to be generated."""
        self.previous_timestamp = previous_timestamp
        self.last_epoch = last_epoch

    def register_new_listener(self) -> Hashable:
        """Allows SynchroTimer to know how many access points are listening to its signals and, in turn, ensure that
        each listener receives each unique instance of a signal only once."""
        idx = len(self._listeners.keys()) + 1
        self._listeners[idx] = self._signal
        return idx

    def _update_signals_(self):
        """Prepares signals for all _listeners."""
        for l in self._listeners.keys():
            self._listeners[l] = self._signal

    def update(
        self,
        timestamp: float | None = None,
        curr_epoch: int | None = None,
        force: bool | None = False,
    ):
        """Given an input of time/epochs or an overriding flag 'force', determines whether a signal should be
        prepared for the listeners or not. Even if ping_interval_time or ping_interval_epoch was set to None,
        the time and epochs can still be specified here to keep track of them. In such a case, however, they will not
        cause the timer's signal to be set."""

        time_signal = (
            False
            if self.ping_interval_time is None
            else (timestamp - self.previous_timestamp) >= self.ping_interval_time
        )

        epoch_signal = (
            False
            if self.ping_interval_epochs is None
            else (curr_epoch - self.last_epoch) >= self.ping_interval_epochs
        )

        self._signal = time_signal or epoch_signal or force
        if self._signal:
            self._update_signals_()
            self.previous_timestamp = timestamp
            self.last_epoch = curr_epoch

    def ping(self, idx: Hashable):
        """Any listener can call this function along with its registered ID to query the signal."""

        if idx not in self._listeners:
            raise KeyError(f"Unrecognized listener ID {idx}.")
        signal = self._listeners[idx]

        # Either the signal was already False and remains unchanged, or was True and has now been consumed.
        self._listeners[idx] = False
        return signal


class Checkpointer:
    """
    Essentially a stateful-function factory for checkpointing model training at discrete intervals of time and epochs.
    Initialized with references to all necessary objects and data for checkpointing and called by specifying the
    elapsed runtime and number of epochs. However, it can also be used to load existing checkpoints. Consult
    DirectoryTree for a breakdown of how the file structure is organized. A SynchroTimer object needs to be passed to
    the initializer argument 'timer' in order to enable logging functionality. Without it, a Checkpointer object can
    only be used in 'read-only' mode.
    """

    def __init__(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: CosineAnnealingLR,
        dir_tree: DirectoryTree,
        timer: SynchroTimer | None = None,
        logger: logging.Logger = None,
        map_location: MAP_LOCATION = None,
    ):
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.dir_tree = dir_tree
        self.timer = timer
        self.runtime = 0.0 if self.timer is None else self.timer.previous_timestamp
        self.last_epoch = -1 if self.timer is None else self.timer.last_epoch
        self.logger = logger if logger is not None else logging.getLogger(__name__)
        logger.debug("Successfully initialized checkpointer.")
        self._load_latest(map_location)

    def __call__(self, force_checkpoint: bool = False):
        if self.timer is None:
            raise RuntimeError(
                "The log functionality of Checkpointer is enabled only when a valid timer has been set."
            )
        if self._signal or force_checkpoint:
            runtime = self.timer.previous_timestamp
            last_epoch = self.timer.last_epoch
            output_file = self.dir_tree.model_checkpoints_dir / f"{runtime}.pt"
            torch.save(
                {
                    "model_state_dict": self.model.state_dict(),
                    "optimizer_state_dict": self.optimizer.state_dict(),
                    "scheduler_state_dict": self.scheduler.state_dict(),
                    "epochs": last_epoch,
                    "torch_rng_state": torch.get_rng_state(),
                    "numpy_rng_state": np.random.get_state(),
                    "python_rng_state": random.getstate(),
                },
                output_file,
            )
            self.runtime = runtime
            self.last_epoch = last_epoch
            self.logger.debug(f"Checkpointed model training at f{str(output_file)}")

    @property
    def timer(self) -> SynchroTimer:
        return self._timer

    @timer.setter
    def timer(self, new_timer: SynchroTimer):
        if new_timer is None:
            self._timer = None
        elif not isinstance(new_timer, SynchroTimer):
            raise ValueError(
                f"Checkpointer requires a valid instance of SynchroTimer, cannot set timer to "
                f"{type(new_timer)}."
            )
        else:
            self._timer = new_timer
            self._timer_id = self._timer.register_new_listener()

    @property
    def _signal(self):
        return False if self.timer is None else self.timer.ping(self._timer_id)

    @classmethod
    def _extract_runtime_from_filename(cls, f: Path) -> float:
        return float(f.name.rstrip(".pt"))

    @classmethod
    def _get_sorted_chkpt_paths(cls, pth: Path, ascending: bool = True) -> list[Path]:
        # pylint: disable=unnecessary-lambda
        latest = sorted(
            pth.rglob("*.pt"),
            key=lambda f: cls._extract_runtime_from_filename(f),
            reverse=not ascending,
        )
        return latest

    @classmethod
    def _load_checkpoint(
        cls,
        pths: Path | list[Path],
        safe_load: bool | None = True,
        map_location: MAP_LOCATION = None,
        get_path: bool = False,
    ):
        # ->  Union[Optional[dict], Tuple[Optional[dict], Path]]:
        """Attempts to load a checkpoint from either a single Path or a list of Paths, attempting each one in the
        order they occur. If 'safe_load' is set to False, the first checkpoint in the list that is readable from disk
        is loaded. It is set to True by default - i.e. if the first checkpoint cannot be loaded, an error is raised.
        'map_location' has been provided for compatibility with GPUs."""

        if isinstance(pths, Path):
            pths = [pths]

        state_dicts = None
        pth = None
        for pth in pths:
            try:
                state_dicts = torch.load(pth, map_location=map_location)
            except Exception as e:
                if safe_load:
                    raise RuntimeError(
                        f"Could not safely load checkpoint at {pth}"
                    ) from e
                cls.logger.info(
                    f"Found possibly corrupt checkpoint at {pth}, reverting to an earlier checkpoint."
                )
            else:
                break

        return (state_dicts, pth) if get_path else state_dicts

    def _load_latest(
        self, safe_load: bool | None = True, map_location: MAP_LOCATION = None
    ):
        """Attempts to load a previously saved checkpoint in order to resume model training. If a checkpoint is
        successfully loaded, the model, optimizer and scheduler state dictionaries are appropriately loaded and the
        relevant values of runtime and last_epoch are updated, else, the state dictionaries and other object
        attributes are left untouched.  If 'safe_load' is set to False, the most recent checkpoint that is readable
        from disk is loaded. Be careful with this setting - it is possible for the loaded checkpoint data and metrics
        data to be out of sync in such a scenario. It is set to True by default - i.e. if the latest checkpoint cannot
        be loaded, a RuntimeError is raised. 'map_location' has been provided for compatibility with GPUs."""

        latest = self._get_sorted_chkpt_paths(
            self.dir_tree.model_checkpoints_dir, ascending=False
        )
        state_dicts, pth = self._load_checkpoint(
            pths=latest, safe_load=safe_load, map_location=map_location, get_path=True
        )

        if state_dicts is None:
            self.logger.info(
                f"No valid checkpoints found at {self.dir_tree.model_checkpoints_dir}."
            )
            return

        # state_dicts = torch.load(latest, map_location=map_location)
        self.model.load_state_dict(state_dicts["model_state_dict"])
        self.optimizer.load_state_dict(state_dicts["optimizer_state_dict"])
        self.scheduler.load_state_dict(state_dicts["scheduler_state_dict"])
        torch_rng_state = state_dicts["torch_rng_state"]
        # Fix needed for compatibilty with cuda, not yet tested for repeatability!!
        if "cpu" not in str(torch_rng_state.device.type):
            torch_rng_state = torch_rng_state.cpu()
        torch.set_rng_state(torch_rng_state)
        np.random.set_state(state_dicts["numpy_rng_state"])
        random.setstate(state_dicts["python_rng_state"])
        self.last_epoch = state_dicts["epochs"]
        self.runtime = self._extract_runtime_from_filename(pth)
        self.logger.info(f"Loaded existing checkpoint from {str(pth)}")
