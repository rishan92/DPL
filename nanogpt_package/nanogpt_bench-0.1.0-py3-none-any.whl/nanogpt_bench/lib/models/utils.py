from __future__ import annotations

import numpy as np
import torch

from nanogpt_bench.lib.core.constants import GPTConfig
from nanogpt_bench.lib.models.nanogpt import GPT
from nanogpt_bench.lib.utils import AttrDict


def get_model(config: AttrDict) -> torch.nn.Module:
    config = GPTConfig(**config)
    return GPT(config)


def count_parameters_in_bytes(model: torch.nn.Module) -> float:
    """
    Returns the model parameters in bytes.
    """
    return float(
        np.sum(
            np.prod(v.size())
            for name, v in model.named_parameters()
            if "auxiliary" not in name
        )
    )


def get_model_flops(model: torch.nn.Module):
    # we only count Weight FLOPs, all other layers (LayerNorm, Softmax, etc.) are effectively irrelevant
    # we count actual FLOPs, not MACs. Hence, 2* all over the place
    # basically for any matrix multiply A (BxC) @ B (CxD) -> (BxD) flops are 2*B*C*D

    block_size = model.config.block_size
    n_embd = model.config.n_embd
    n_head = model.config.n_head
    n_layer = model.config.n_layer
    vocab_size = model.config.vocab_size

    out = dict()
    head_size = n_embd // n_head

    # attention blocks
    # 1) the projection to key, query, values
    out["attention/kqv"] = 2 * block_size * (n_embd * 3 * n_embd)
    # 2) calculating the attention scores
    out["attention/scores"] = 2 * block_size * block_size * n_embd
    # 3) the reduction of the values (B, nh, T, T) x (B, nh, T, hs) -> (B, nh, T, hs)
    out["attention/reduce"] = 2 * n_head * (block_size * block_size * head_size)
    # 4) the final linear projection
    out["attention/proj"] = 2 * block_size * (n_embd * n_embd)
    out["attention"] = sum(
        out["attention/" + k] for k in ["kqv", "scores", "reduce", "proj"]
    )

    # MLP blocks
    ffw_size = 4 * n_embd  # feed forward size
    out["mlp/ffw1"] = 2 * block_size * (n_embd * ffw_size)
    out["mlp/ffw2"] = 2 * block_size * (ffw_size * n_embd)
    out["mlp"] = out["mlp/ffw1"] + out["mlp/ffw2"]

    # the transformer and the rest of it
    out["block"] = out["attention"] + out["mlp"]
    out["transformer"] = n_layer * out["block"]
    out["dense"] = 2 * block_size * (n_embd * vocab_size)

    # forward,backward,total
    out["forward_total"] = out["transformer"] + out["dense"]
    out["backward_total"] = 2 * out["forward_total"]  # use common estimate of bwd = 2*fwd
    out["total"] = out["forward_total"] + out["backward_total"]

    return out["total"]
