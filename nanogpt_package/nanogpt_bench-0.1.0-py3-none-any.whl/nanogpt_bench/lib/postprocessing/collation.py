# import json
import logging
import os
import traceback as tb
from pathlib import Path
from typing import Iterable, Optional, Sequence

import pandas as pd

from nanogpt_bench.lib.core import constants
from nanogpt_bench.lib.core.search_space import get_config_grid
from nanogpt_bench.lib.utils import DirectoryTree

_log = logging.getLogger(__name__)
metric_df_index_levels = [
    constants.MetricDFIndexLevels.task_id.value,
    constants.MetricDFIndexLevels.config_id.value,
    constants.MetricDFIndexLevels.epoch.value,
]


def sorted_metric_files(metric_dir: Path, descending: bool = True) -> Sequence[Path]:
    return sorted(
        metric_dir.rglob("*.pkl.gz"),
        key=lambda f: float(f.name.rstrip(".pkl.gz")),
        reverse=descending,
    )


def safe_load_df(
    df_pkl_files: Iterable[Path],
    cleanup: bool = False,
    last: bool = True,
    search_space_id: int = 0,
) -> Optional[pd.DataFrame]:
    dfs = []
    for pkl in df_pkl_files:
        try:
            _df: pd.DataFrame = pd.read_pickle(pkl)
            # remove duplicate entries
            _df.drop_duplicates(inplace=True)
        except Exception as e:
            _log.info(
                f"DataFrame {pkl} is likely corrupted, trying next file in sequence."
            )
            _log.debug(
                f"Could not load DataFrame from {pkl} because of the following error:\n{tb.format_exc()}"
            )
            _log.debug(f"Error message: {e}")
            if cleanup:
                os.remove(pkl)
        else:
            _log.info(f"Loaded Pandas DataFrame from {pkl}.")
            if len(_df) == len(get_config_grid(search_space_id)):
                _log.debug("All entries are present in the DataFrame.")
                break
            dfs.append(_df)
            if last:
                break

    if dfs:
        df = pd.concat(dfs, axis=0)
        df.drop_duplicates(inplace=True)
        return df
    return None


task_metadata_columns = [m for m in constants.standard_task_metrics if m != "config"]
config_id_lvl = constants.MetricDFIndexLevels.config_id.value
task_id_lvl = constants.MetricDFIndexLevels.task_id.value


def task_df_hack(task_df: pd.DataFrame) -> pd.DataFrame:
    # TODO: Fix this hack at its source
    metadata = task_df[task_metadata_columns].droplevel(1, axis=1)
    configs = task_df["config"]
    return pd.concat({"config": configs, "metadata": metadata}, axis=1)


# TODO: Implement 'save_summary'
# TODO: Fix implementation of 'anonymize' - we still want to retain the "Epoch" index level.
def collate_task_models(
    task_id: int,
    base_dir: Optional[Path] = None,
    dtree: Optional[DirectoryTree] = None,
    cleanup: bool = False,
    save_summary: bool = False,  # pylint: disable=unused-argument
    anonymize: bool = False,
) -> Optional[pd.DataFrame]:
    """
    Iterates over all models evaluated by a particular task, collects the available model-level metrics, and
    returns a collated version of the metrics as a Pandas DataFrame. Either a directory 'base_dir' that serves as the
    base directory for an appropriate directory tree or an instantiated DirectoryTree object 'dtree' should be given
    alongside the task_id.

    :param task_id: int
        The task id within all available tasks at the given directory tree to be handled.
    :param base_dir: Path-like
        The base directory where the DirectoryTree object will be rooted. Either this or 'dtree' must be given.
    :param dtree: DirectoryTree
        An instantiated DirectoryTree object defining the directory tree where the required data will be sought.
    :param cleanup: bool
        When True, also removes stray files, such as error descriptions from repeated runs, that are no longer
        relevant. Default: False
    :param save_summary: bool
        When True, a summary of the current status of the models w.r.t. the expected training configuration is saved
        in the task directory. Default: False
    :param anonymize: bool
        When True, the original task id and model id of the metric data is removed from the final, returned DataFrame.
        Default: False
    :return: pd.DataFrame or None
        If no valid metric data could be loaded from the directory tree, most likely because none of the runs were
        completed enough to generate the metrics data or all generated data was corrupt, None is returned. Otherwise, a
        pandas DataFrame containing the collated metric data of all models evaluated under this task is returned.
    """

    assert (
        base_dir is not None or dtree is not None
    ), "One of 'base_dir' or 'dtree' must be given."

    if dtree is None:
        dtree = DirectoryTree(base_dir=base_dir, task_id=task_id, read_only=True)
    else:
        dtree.task_id = task_id

    if not dtree.task_dir.exists():
        raise RuntimeError(
            f"No existing data found for task id {dtree.task_id} in the directory tree rooted at "
            f"{dtree.base_dir}."
        )

    # with open(dtree.task_config_file) as fp:
    #     task_config = json.load(fp)

    # train_config = task_config["train_config"]
    # expected_num_epochs = train_config["epochs"]

    latest_task_metrics = sorted_metric_files(dtree.task_metrics_dir, descending=True)
    task_metrics = safe_load_df(latest_task_metrics, cleanup=cleanup, last=False)

    if task_metrics is None:
        _log.debug(
            f"No valid task metrics DataFrame found for task id {dtree.task_id} in the directory tree "
            f"rooted at {dtree.base_dir}"
        )
        return None

    task_metrics = task_df_hack(task_metrics)
    assert (
        "metadata",
        config_id_lvl,
    ) in task_metrics.columns, f"Unable to process task metrics DataFrame that does not have the column ('metadata', '{config_id_lvl}')."

    task_metrics = task_metrics.set_index(("metadata", config_id_lvl)).rename_axis(
        [config_id_lvl], axis=0
    )

    models = dtree.existing_models
    model_dfs = []
    for m in models:
        dtree.config_id = int(m.stem)
        latest_model_metrics = sorted_metric_files(
            dtree.model_metrics_dir, descending=True
        )
        model_metrics = safe_load_df(latest_model_metrics, cleanup=cleanup)

        if model_metrics is None:
            _log.debug(f"No valid metric DataFrame found for model id {dtree.config_id}.")
            continue

        model_metrics.index = pd.MultiIndex.from_product(
            [model_metrics.index, [dtree.config_id]],
            names=model_metrics.index.names + [config_id_lvl],
        )
        model_dfs.append(model_metrics)

    if not model_dfs:
        return None
    else:
        big_model_df = pd.concat(model_dfs, axis=0)
        task_df = big_model_df.join(
            task_metrics, on=config_id_lvl, how="left", lsuffix="_model", rsuffix="_task"
        )

        # TODO: Fix this hack at its source
        import numpy as np

        if ("train", np.nan) in task_df.columns:
            task_df = task_df.drop([("train", np.nan)], axis=1)
        if ("valid", np.nan) in task_df.columns:
            task_df = task_df.drop([("valid", np.nan)], axis=1)

        if anonymize:
            task_df = task_df.reset_index(drop=True)
        else:
            # TODO: Make the 'task_id' name programmatically consistent in 'assign'.
            task_df = task_df.assign(TaskIndex=dtree.task_id).set_index(
                task_id_lvl, append=True
            )
            task_df = task_df.reorder_levels(metric_df_index_levels, axis=0)

        return task_df


# TODO: Implement 'save_summary'
def collate_tasks(
    base_dir: Optional[Path] = None,
    dtree: Optional[DirectoryTree] = None,
    cleanup: bool = False,
    save_summary: bool = False,
    anonymize: bool = False,
) -> Optional[pd.DataFrame]:
    """
    Collate the metrics of all evaluated models in all tasks under the given directory tree, as defined by either
    the specified base directory 'base_dir' or an instance of DirectoryTree passed as 'dtree'. The flag 'cleanup', when
    True, also removes stray files, such as error descriptions from repeated runs, that are no longer relevant. When
    the flag 'save_summary' is True, a summary of the current status of all the tasks w.r.t. their expected training
    configurations is saved in the base directory.

    :param base_dir: Path-like
        The base directory where the DirectoryTree object will be rooted. Either this or 'dtree' must be given.
    :param dtree: DirectoryTree
        An instantiated DirectoryTree object defining the directory tree where the required data will be sought.
    :param cleanup: bool
        When True, also removes stray files, such as error descriptions from repeated runs, that are no longer
        relevant. Default: False
    :param save_summary: bool
        When True, a summary of the current status of the models w.r.t. the expected training configuration is saved
        in the task directory. A job-level summary of all the tasks is also saved in the base directory. Default: False
    :param anonymize: bool
        When True, the original task id and model id of the metric data is removed from the final, returned DataFrame.
        Default: False
    :return: pd.DataFrame or None
        If no valid metric data could be loaded from the directory tree, most likely because none of the runs were
        completed enough to generate the metrics data or all generated data was corrupt, None is returned. Otherwise, a
        pandas DataFrame containing the collated metric data of all models and all tasks evaluated under this task is
        returned.
    """

    assert (
        base_dir is not None or dtree is not None
    ), "One of 'base_dir' or 'dtree' must be given."

    if dtree is None:
        dtree = DirectoryTree(base_dir=base_dir, read_only=True)

    tasks = dtree.existing_tasks
    if tasks is None:
        _log.info(
            f"Found no existing task data sub-directories in the directory tree rooted at {dtree.base_dir}"
        )
        return None

    tasks = list(map(lambda t: int(t.stem), tasks))
    ntasks = len(tasks)
    task_dfs = []

    for i, t in enumerate(tasks, start=1):
        _log.info(f"Processing task {i}/{ntasks}")
        task_df = collate_task_models(
            task_id=t,
            dtree=dtree,
            cleanup=cleanup,
            save_summary=save_summary,
            anonymize=anonymize,
        )
        if task_df is None:
            _log.debug(
                f"No valid metric data found for task id {t} in the directory tree rooted at {dtree.base_dir}"
            )
            continue

        task_dfs.append(task_df)

    if not task_dfs:
        _log.info(
            f"Found no valid metric data for any of the tasks in the directory tree rooted at {dtree.base_dir}"
        )
        return None
    else:
        big_task_df = pd.concat(task_dfs, axis=0)
        big_task_df = big_task_df.reorder_levels(metric_df_index_levels, axis=0)

        return big_task_df
