import glob
import os
import re
import shutil


def copy_only_latest_metrics(source_dir, dest_dir, logger):

    for task_dir in glob.glob(os.path.join(source_dir, "*/")):
        task_name = "0"
        new_task_dir = os.path.join(dest_dir, task_name)
        os.makedirs(new_task_dir, exist_ok=True)
        new_metrics_dir = os.path.join(new_task_dir, "metrics")
        os.makedirs(new_metrics_dir, exist_ok=True)
        new_models_dir = os.path.join(new_task_dir, "models")
        os.makedirs(new_models_dir, exist_ok=True)

        task_metric_files = glob.glob(os.path.join(task_dir, "metrics/*.pkl.gz"))
        # Copy the task-level metric files to the new metrics directory
        # pylint: disable=expression-not-assigned
        [shutil.copy(file, new_metrics_dir) for file in task_metric_files]

        for model_idx, model_dir in enumerate(
            glob.glob(os.path.join(task_dir, "models/*/"))
        ):

            try:
                match = re.search(r"/(\d+)/$", model_dir)
                model_name = match.group(1)
                new_model_dir = os.path.join(new_models_dir, model_name)
                os.makedirs(new_model_dir, exist_ok=True)

                new_checkpoints_dir = os.path.join(new_model_dir, "checkpoints")
                os.makedirs(new_checkpoints_dir, exist_ok=True)

                new_metrics_dir = os.path.join(new_model_dir, "metrics")
                os.makedirs(new_metrics_dir, exist_ok=True)

                # Find the highest checkpoint file for the model
                checkpoint_files = glob.glob(os.path.join(model_dir, "checkpoints/*.pt"))
                highest_checkpoint_file = max(checkpoint_files, key=os.path.getctime)

                # Find the highest metric file for the model
                model_metric_files = glob.glob(
                    os.path.join(model_dir, "metrics/*.pkl.gz")
                )
                highest_model_metric_file = max(model_metric_files, key=os.path.getctime)

                # Copy the highest metric file for the model to the new metrics directory
                shutil.copy(highest_model_metric_file, new_metrics_dir)

                # Copy the highest checkpoint file for the model to the new checkpoints directory
                shutil.copy(highest_checkpoint_file, new_checkpoints_dir)

            except Exception as e:
                logger.warning(
                    f"Error copying model {model_idx} for task {task_name}: {e}"
                )
                logger.info(
                    f"Removing model {model_idx} for task {task_name} from new directory."
                )
                continue

        # Copy the task_config.json file to the new model directory
        shutil.copy(os.path.join(task_dir, "task_config.json"), new_task_dir)

    return dest_dir
