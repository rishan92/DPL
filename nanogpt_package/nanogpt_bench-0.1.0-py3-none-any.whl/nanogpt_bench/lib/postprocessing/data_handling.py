from typing import Union

import pandas as pd


def collapse_index_names(
    index: pd.MultiIndex, levels: list = None, nlevels: int = None, separator: str = "-"
) -> Union[pd.Index, pd.MultiIndex]:
    """Collapses the index labels in a MultiIndex. The levels to be collapsed can be passed as either a list of
    specific levels in "levels" or an integer can be passed to "nlevels" indicating that the first "nlevels" levels
    should be collapsed into one level - the first level."""

    if levels is not None and nlevels is not None:
        raise RuntimeError(
            "Either a list of index names or the number of indices to be collapsed should be provided, "
            "not both."
        )

    if levels is not None:
        inds = [index.names.index(i) for i in levels]
        old_names = levels
    else:
        inds = list(range(nlevels))
        old_names = [index.names[i] for i in inds]

    compressor = separator.join([f"{{0[{i}]}}" for i in inds]).format

    if len(inds) > index.nlevels:
        raise RuntimeError(
            f"Number of levels to be collapsed - {len(inds)} - cannot exceed the number of levels in "
            f"the original index - {index.nlevels}"
        )
    if len(inds) < index.nlevels:
        remainder = [i for i in range(index.nlevels) if i not in inds]
        # pylint: disable=unnecessary-lambda
        new_ind: list = [index.map(lambda i: (compressor(i)))] + [
            index.get_level_values(j) for j in remainder
        ]
        new_names = [compressor(index.names)] + index.names.difference(old_names)
        new_ind: pd.MultiIndex = pd.MultiIndex.from_arrays(new_ind, names=new_names)
    else:
        new_ind: pd.Index = index.map(
            # pylint: disable=unnecessary-lambda
            lambda i: compressor(i)
        )
        new_ind.name = compressor(index.names)

    return new_ind


def to_wide_format(df: pd.DataFrame) -> pd.DataFrame:
    """Converts an input DataFrame in the original metrics storage format to a wide-format one. The returned DataFrame
    has three top-level columns: "sampling_index", "features", and "labels". SamplingIndex has the sub-columns "taskid"
    and "model_idx" and the corresponding values from the original index. The values of the "Epoch" level of the
    original index are moved underneath "features" instead in the sub-column "epoch" alongside all the sub-columns of
    "model_config" from the original DataFrame. All the metrics in the original DataFrame (with a name <metric>)
    recorded under a <set>: one of "train", "valid", and "test", are moved to the sub-column "<set>-<metric>". The
    sub-columns "FLOPS" and "latency" of "diagnostic" are also moved underneath "labels". Finally, "size_bytes" from
    "metadata" is moved underneath "labels". The index itself is set to a simple RangeIndex."""

    # Separate out the features
    features = df.loc[:, "config"]
    features.loc[:, "epoch"] = df.index.get_level_values("Epoch")

    # Separate out the labels
    labels = df.loc[:, ["train", "valid"]]
    labels.columns = collapse_index_names(labels.columns, nlevels=2)
    diagnostics = df.loc[:, ("diagnostic", ["FLOPS", "latency", "runtime"])]
    labels.loc[:, diagnostics.columns.get_level_values(1)] = diagnostics.values
    labels.loc[:, "size_bytes"] = df.loc[:, ("metadata", "size_bytes")]

    # Extract the original sampling index
    sampling_index = df.index.to_frame(index=False)
    features.index = sampling_index.index
    labels.index = sampling_index.index
    sampling_index.drop("Epoch", axis=1, inplace=True)

    combined = pd.concat(
        {"sampling_index": sampling_index, "features": features, "labels": labels}, axis=1
    )

    return combined
