"""
Collate all the data generated during training into one big pandas DataFrame. This script was designed specifically to
work with the directory structure defined by the class DirectoryTree. The individual DataFrame objects are expected to
contain all their data as columns with the appropriate metrics names. Theoretically, these can be anything, but the
code has been tested for the following for task and model metrics only:

tasks
-----
    - config_id
    - config
    - global_seed
    - size_bytes

models - [train/valid]
------
    - duration
    - forward_duration
    - data_load_duration
    - loss
    - data_transfer_duration
    - backprop_duration

models - diagnostic
    - FLOPS
    - latency
    - runtime
    - cpu_percent
    - memory_ram
    - memory_swap
"""

import argparse
import logging
import shutil
import sys
from pathlib import Path

from nanogpt_bench.lib.postprocessing import collation, data_handling, utils

_log = logging.getLogger(__name__)

if __name__ == "__main__":
    fmt = logging.Formatter(
        "[%(asctime)s] %(name)s %(levelname)s: %(message)s", datefmt="%m/%d %H:%M:%S"
    )
    ch = logging.StreamHandler(stream=sys.stdout)
    ch.setLevel(logging.DEBUG)
    ch.setFormatter(fmt)
    _log.addHandler(ch)
    collation._log.addHandler(ch)  # pylint: disable=protected-access

    parser = argparse.ArgumentParser(
        "Collates all results from the DataFrames produced after successful NASLib "
        "training runs into a single large DataFrame."
    )
    parser.add_argument(
        "--base_dir",
        type=Path,
        help="The base directory for the directory tree, or the root directory within which multiple "
        "such base directories exist, depending on whether the script is running in 'stand-alone' "
        "or 'cluster' mode. See '--workerid' for details.",
    )
    parser.add_argument(
        "--file",
        default=None,
        type=Path,
        help="The desired output filename. The filename should not carry any extension as '.pkl.gz' "
        "will be automatically appended to it, unless the extension is already '.pkl.gz'. "
        "Default: <base_dir>/data.pkl.gz",
    )
    parser.add_argument(
        "--wide_format",
        action="store_true",
        help="When given, the raw DataFrame is converted into wide format.",
    )
    parser.add_argument(
        "--only_latest",
        action="store_true",
        help="When given, only the latest metrics DataFrame is used for collation.",
    )
    parser.add_argument(
        "--debug", action="store_true", help="When given, enables debug level output."
    )
    args = parser.parse_args()

    if args.debug:
        _log.setLevel(logging.DEBUG)
        collation._log.setLevel(logging.DEBUG)  # pylint: disable=protected-access
    else:
        _log.setLevel(logging.INFO)
        collation._log.setLevel(logging.WARNING)  # pylint: disable=protected-access

    if args.only_latest:
        out_dir = args.base_dir / "latest"
        base_dir = utils.copy_only_latest_metrics(args.base_dir, out_dir, logger=_log)
    else:
        out_dir = base_dir = args.base_dir

    wid = 0

    _log.info(f"Worker {wid}: Beginning metric data collation at {base_dir}.")

    try:
        collated_df = collation.collate_tasks(base_dir=base_dir)
    except Exception as e:
        _log.warning(
            f"Worker {wid}: Could not collate metrics DataFrames. Exiting. Cause: {str(e)}"
        )
        sys.exit(1)

    outfile: Path = (
        args.base_dir / "metrics.pkl.gz" if args.file is None else args.file.resolve()
    )
    if collated_df is None:
        _log.info(f"Worker {wid}: No valid metric data found at: {args.base_dir}")
    else:
        collated_df.to_pickle(outfile)

    _log.info(f"Worker {wid}: Finished metric data collation.")

    if args.wide_format:
        _log.info(f"Worker {wid}: Converting collated DataFrame into wide format.")
        wide_df = data_handling.to_wide_format(collated_df)
        wide_df.to_pickle(outfile)
        _log.info(
            f"Worker {wid}: Finished converting collated DataFrame into wide format."
        )

    if args.only_latest:
        shutil.rmtree(out_dir)
