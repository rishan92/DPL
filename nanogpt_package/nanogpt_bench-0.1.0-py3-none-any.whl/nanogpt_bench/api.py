from __future__ import annotations

import logging
from enum import Enum, unique
from pathlib import Path

import numpy as np
import pandas as pd

import nanogpt_bench.download
from nanogpt_bench.lib.core.constants import features

try:
    import shutil

    from nanogpt_bench.lib.core.constants import Datasets as _Tasks
    from nanogpt_bench.lib.core.constants import TrainConfig
    from nanogpt_bench.lib.core.sample import run_task
    from nanogpt_bench.lib.core.search_space import get_config_id
    from nanogpt_bench.lib.utils import AttrDict, DirectoryTree, MetricLogger
except ImportError as e:
    DATA_CREATION_AVAILABLE = False
else:
    DATA_CREATION_AVAILABLE = True

_log = logging.getLogger(__name__)
_log.setLevel(logging.DEBUG)


@unique
class BenchmarkTypes(Enum):
    Live = "live"
    Table = "table"
    Surrogate = "surrogate"  # TODO: implement one day


@unique
class BenchmarkTasks(Enum):
    Shakespeare_char = "shakespeare_char"
    Shakespeare = "shakespeare"
    OpenWebText = "openwebtext"
    # WMT2014_EN_GER = "wmt2014_en_ger"
    # WMT2014_EN_FR = "wmt2014_en_fr"


BenchmarkTaskIdMapping = {
    "shakespeare_char": 0,
    "shakespeare": 1,
    "openwebtext": 2,
}


class Benchmark:
    _call_fn = None
    _table = None
    _surrogates = None
    _known_metrics = (
        "train_loss",
        "valid_loss",
        "FLOPS",
        "latency",
        "runtime",
        "size_bytes",
    )

    def __init__(
        self,
        task: str | BenchmarkTasks,
        mode: str | BenchmarkTypes = BenchmarkTypes.Live,
        download: bool = True,
        save_dir: str | Path = "nanogpt_bench_data",
        metrics: list[str] = None,
        lazy: bool = False,
        search_space_id: int = None,
    ):
        if isinstance(task, str):
            try:
                task = BenchmarkTasks(task.lower())
            except ValueError as e:
                raise ValueError(
                    f"Unknown task: {task}. Must be one of: {[x.value for x in BenchmarkTasks]}"
                ) from e

        if isinstance(mode, str):
            try:
                mode = BenchmarkTypes(mode.lower())
            except ValueError as e:
                raise ValueError(
                    f"Unknown mode: {mode}. Must be one of: {[x.value for x in BenchmarkTypes]}"
                ) from e

        if metrics is not None:
            metrics = set(metrics)
            unknown_metrics = metrics - set(self._known_metrics)
            if any(unknown_metrics):
                raise ValueError(
                    f"Unknown metrics: {unknown_metrics}. Must be one of: {self._known_metrics}"
                )

        if search_space_id is None:
            search_space_id = 0
        self.search_space_id = search_space_id

        self.task = task
        self.mode = mode
        self.metrics = tuple(metrics) if metrics is not None else self._known_metrics

        # Directories
        self.save_dir = Path(save_dir)
        self.task_dir = self.save_dir / "nanogpt_bench_data" / task.name
        self.table_dir = self.save_dir / "nanogpt_bench_tables"
        self.surrogate_dir = self.save_dir / "nanogpt_bench_surrogates"

        self._lazy = lazy
        if download:
            if mode is BenchmarkTypes.Live:
                self.task_dir.mkdir(parents=True, exist_ok=True)
                nanogpt_bench.download.download_task(task.name, self.task_dir)
            if mode is BenchmarkTypes.Table:
                if not self.table_dir.exists():
                    raise NotImplementedError(
                        "Table download is not implemented yet. Please ask Maciej for the file."
                    )
                    # nanogpt_bench.download.download_metrics(self.table_dir)
            if mode is BenchmarkTypes.Surrogate:
                pass

        loaders = {
            BenchmarkTypes.Live: self._load_live,
            BenchmarkTypes.Table: self._load_table,
            BenchmarkTypes.Surrogate: self._load_surrogate,
        }

        loaders[mode]()

    def __call__(
        self,
        config: dict,
        epochs: int | None = 50,
        full_trajectory: bool = False,
        **kwargs,
    ):
        if self._call_fn is None:
            raise RuntimeError("No benchmarking function defined. This is a bug.")
        return self._call_fn(
            config=config, epochs=epochs, full_trajectory=full_trajectory, **kwargs
        )

    def _load_live(self):
        self._call_fn = self._benchmark_live

    def _benchmark_live(
        self,
        config: dict,
        epochs: int | None = 50,
        full_trajectory: bool = False,
        train_config: dict = None,
        worker_dir: str | Path | None = None,
        clean_up: bool = False,
        config_id: int | None = None,
        **kwargs,
    ) -> dict:

        if not DATA_CREATION_AVAILABLE:
            raise RuntimeError(
                "Cannot create data without additional dependencies."
                " Please install nanogpt_bench[create_data]"
            )

        if config_id is None:
            config_id = get_config_id(config, search_space_id=self.search_space_id)

        if train_config is None:
            if self.task is BenchmarkTasks.OpenWebText:
                block_size = 512
            else:
                block_size = 32
            train_config = TrainConfig(
                **{
                    "epochs": epochs,
                    "config_id": config_id,
                    "block_size": block_size,
                }
            ).__dict__

        base_dir = (
            Path(worker_dir) if worker_dir is not None else Path.cwd()
        ) / "nanogpt_bench"
        base_dir.mkdir(exist_ok=True, parents=True)

        task = _Tasks[self.task.name]
        args = {
            **dict(
                base_dir=base_dir,
                task_id=BenchmarkTaskIdMapping[task.value],
                train_config=AttrDict(train_config),
                task=task,
                data_dir=self.task_dir,
                local_seed=None,
                global_seed=0,
                debug=True,
                config=config,
                config_id=config_id,
                search_space_id=self.search_space_id,
            ),
            **kwargs,
        }

        run_task(**args)

        dir_tree = DirectoryTree(
            base_dir=base_dir,
            task_id=BenchmarkTaskIdMapping[task.value],
            config_id=config_id,
            read_only=True,
        )

        metric_pth = MetricLogger.get_sorted_metric_paths(pth=dir_tree.model_metrics_dir)
        if isinstance(metric_pth, list) and len(metric_pth):
            metric_pth = metric_pth[-1]
        df: pd.DataFrame = pd.read_pickle(metric_pth)

        if full_trajectory:
            result = df.to_dict(orient="index")
        else:
            result = df.loc[epochs].to_dict()

        if clean_up:
            shutil.rmtree(dir_tree.base_dir, ignore_errors=True)

        return result

    def _load_table(self):
        assert self.table_dir.exists() and self.table_dir.is_dir()

        table = pd.read_pickle(self.table_dir / "metrics.pkl.gz")

        if table["features"].columns.intersection(features).size != len(features):
            raise ValueError(
                f"The given performance datasets at {self.table_dir} could not "
                f"be resolved against the known search space consisting of "
                f"the parameters {features}"
            )

        # pylint: disable=attribute-defined-outside-init
        self._features = table["features"].columns
        self._labels = table["labels"].columns
        self._table_features = table.loc[:, "features"]
        self._table_labels = table.loc[:, "labels"]
        self._table_features.rename_axis("Sample ID", axis=0, inplace=True)
        self._table_features = self._table_features.reset_index()
        self._call_fn = self._benchmark_tabular
        # pylint: enable=attribute-defined-outside-init

    def _benchmark_tabular(
        self,
        config: dict,
        epochs: int | None = 50,
        full_trajectory: bool = False,
        **kwargs,  # pylint: disable=unused-argument
    ) -> dict:

        assert epochs >= 1
        assert self._table_features is not None and self._table_labels is not None, (
            "No performance dataset has been loaded into memory - a tabular query "
            "cannot be made."
        )

        query_df = pd.DataFrame(
            config, index=list(range(1, epochs + 1)) if full_trajectory else [epochs]
        )
        query_df.rename_axis("epoch", axis=0, inplace=True)
        query_df = query_df.reset_index()

        check = self._features.difference(query_df.columns)
        if check.size:
            raise ValueError(
                f"The given query is missing the following features: {check.tolist()}"
            )

        idx = pd.merge(self._table_features, query_df, how="inner")["Sample ID"]

        if idx.size == 0:
            raise KeyError(
                f"Could not find any entries for the config {config} at "
                f"{epochs} epochs."
            )
        elif full_trajectory:
            # Return the full trajectory, but only for the first instance of this config
            # that was found.
            result = self._table_labels.loc[idx, :].iloc[:epochs]
            return result.to_dict("records")
        else:
            # Return only the first result that was found
            result = self._table_labels.loc[idx, :].iloc[:1]
            return result.to_dict("records")[0]

    def _load_surrogate(self):
        pass

    def sample_config(self, random_state: int | np.random.RandomState | None = None):

        from nanogpt_bench.lib.core.search_space import get_config_grid

        if not isinstance(random_state, np.random.RandomState):
            random_state = np.random.RandomState(random_state)

        config_grid = get_config_grid(self.search_space_id)
        index = random_state.randint(len(config_grid))

        config = config_grid[index].get_dictionary()

        return config
