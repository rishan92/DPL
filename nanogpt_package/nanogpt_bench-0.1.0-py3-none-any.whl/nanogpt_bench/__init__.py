import logging

from nanogpt_bench.api import Benchmark, BenchmarkTasks, BenchmarkTypes

_log = logging.getLogger(__name__)
