""" This file has been used as-is from  https://github.com/karpathy/nanoGPT/blob/master/data/."""

import os
import pickle

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

import nanogpt_bench.data.openwebtext.prepare as openwebtext
import nanogpt_bench.data.shakespeare.prepare as shakespeare
import nanogpt_bench.data.shakespeare_char.prepare as shakespeare_char

task_download_mapping = {
    "OpenWebText": openwebtext,
    "Shakespeare": shakespeare,
    "Shakespeare_char": shakespeare_char,
}


class CustomDataset(Dataset):
    def __init__(self, data_dir, block_size: int = 32, validate: bool = False):
        self.block_size = block_size
        self.validate = validate

        self.train_data = np.memmap(
            os.path.join(data_dir, "train.bin"), dtype=np.uint16, mode="r"
        )
        self.valid_data = np.memmap(
            os.path.join(data_dir, "valid.bin"), dtype=np.uint16, mode="r"
        )

        self.data = self.valid_data if validate else self.train_data

        # Attempt to derive vocab_size from the dataset
        meta_path = os.path.join(data_dir, "meta.pkl")
        self.meta_vocab_size = None
        if os.path.exists(meta_path):
            with open(meta_path, "rb") as f:
                meta = pickle.load(f)
            self.meta_vocab_size = meta["vocab_size"]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, ix=None, batch_size=12, pin_memory=True, device=None):
        # if torch.is_tensor(ix):
        #     ix = ix.tolist()

        ix = torch.randint(len(self.data) - self.block_size, size=(batch_size,))

        x = torch.stack(
            [
                torch.from_numpy((self.data[i : i + self.block_size]).astype(np.int64))
                for i in ix
            ]
        )
        y = torch.stack(
            [
                torch.from_numpy(
                    (self.data[i + 1 : i + self.block_size + 1]).astype(np.int64)
                )
                for i in ix
            ]
        )

        if pin_memory:
            x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(
                device, non_blocking=True
            )
        # x = self.data[ix : ix + self.block_size]
        # y = self.data[ix + 1 : ix + self.block_size + 1]

        # x = torch.from_numpy(x.astype(np.int64))
        # y = torch.from_numpy(y.astype(np.int64))

        return x, y


def collate_fn(batch):
    max_len = max(len(x[0]) for x in batch)

    x_batch = []
    y_batch = []

    for x, y in batch:
        x_pad = torch.nn.functional.pad(x, (0, max_len - len(x)), value=0)
        y_pad = torch.nn.functional.pad(y, (0, max_len - len(y)), value=0)

        x_batch.append(x_pad)
        y_batch.append(y_pad)

    return torch.stack(x_batch), torch.stack(y_batch)


def get_dataloaders(data_dir, batch_size, block_size=32, num_workers=0, device="cpu"):
    dataloaders = dict()

    train_dataset = CustomDataset(
        data_dir=data_dir, block_size=block_size, validate=False
    )
    valid_dataset = CustomDataset(data_dir=data_dir, block_size=block_size, validate=True)

    pin_memory = True if "cuda" in str(device) else False
    dataloaders["train"] = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
    )

    dataloaders["valid"] = DataLoader(
        valid_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
        collate_fn=collate_fn,
    )
    return dataloaders, train_dataset.meta_vocab_size
