import tarfile
from pathlib import Path

import requests

from nanogpt_bench.data import task_download_mapping

METRIC_URL = "https://figshare.com/ndownloader/files/40299109"


def download_and_extract_url(
    url: str, save_dir: str | Path, filename: str, extract: bool = True
):
    """Download and optionally extract a tar file."""
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    save_file = save_dir / filename

    print(f"Starting download of {url}, this might take a while...")
    with requests.get(url, stream=True) as response:
        with open(save_file, "wb") as f:
            f.write(response.raw.read())
    print(f"Download finished. File saved to: {save_file}")

    if extract:
        print("Extracting now...")
        with tarfile.open(save_file, "r") as f:
            f.extractall(path=save_dir)
        print("Done extracting.")


def download_task(dataset_name: str, save_dir: str | Path = "nanogpt_bench_data"):
    """Download the dataset and save it to the specified directory."""
    task_download_mapping[dataset_name].prepare(save_dir)


def download_metrics(save_dir: str | Path = "nanogpt_bench_data"):
    """Download the metrics and save it to the specified directory."""
    download_and_extract_url(METRIC_URL, save_dir, "metrics.tar", extract=False)
